﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Views
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void Dashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            this.Text = Env.APPNAME + "MENU PRINCIPAL | @" + Vendor.Auth.USERNAME + " | " + Vendor.Auth.ROLE;
            SetInfoDashboard();
            BtnConfiguracion.Visible = Vendor.Auth.ROLE == "ADMINISTRADOR" ? true : false;
        }

        private void SetInfoDashboard()
        {
            LblUser.Text = "[@" + Vendor.Auth.USERNAME + "] " + Vendor.Auth.REALNAME;
            LblPerfil.Text = Vendor.Auth.ROLE;
            LblFecha.Text = DateTime.Today.ToLongDateString().ToUpper();
        }

        private void BtnClientes_Click(object sender, EventArgs e)
        {
            Views.Clientes clientes = new Clientes();
            clientes.MdiParent = this;
            clientes.Show();
        }

        private void OpcClientes_Click(object sender, EventArgs e)
        {
            Views.Clientes clientes = new Clientes();
            clientes.MdiParent = this;
            clientes.Show();
        }

        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Views.ViewProductos  prod = new ViewProductos();
            prod.MdiParent = this;
            prod.Show();
        }

        private void marcasProductosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Views.MarcasProducto marcas = new MarcasProducto();
            marcas.MdiParent = this;
            marcas.Show();
        }

        private void categoriasProductosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Views.CategoriasProd cate = new CategoriasProd();
            cate.Show();
        }

        private void BtnProductos_Click(object sender, EventArgs e)
        {
            ViewProductos pro = new ViewProductos();
            pro.MdiParent = this;
            pro.Show();
        }

        private void BtnConfiguracion_Click(object sender, EventArgs e)
        {
            Configuracion.ViewConfiguracion confi = new Configuracion.ViewConfiguracion();
            confi.MdiParent = this;
            confi.Show();
        }

        private void OptInfoGral_Click(object sender, EventArgs e)
        {
            Configuracion.ViewConfiguracion conf = new Configuracion.ViewConfiguracion();
            conf.MdiParent = this;
            conf.Show();
        }

        private void cambiarClaveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Usuarios.ModificarUsuario usu = new Usuarios.ModificarUsuario();
            usu.MdiParent = this;
            usu.Show();
        }

        private void aperturaCajaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ventas.AperturaCajaView aper = new Ventas.AperturaCajaView();
            aper.MdiParent = this;
            aper.Show();
        }

        private void BtnVentas_Click(object sender, EventArgs e)
        {
            Ventas.FacturacionView fact = new Ventas.FacturacionView();
            fact.MdiParent = this;
            fact.Show();
        }

        private void facturacionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ventas.FacturacionView fact2 = new Ventas.FacturacionView();
            fact2.MdiParent = this;
            fact2.Show();
        }
    }
}
