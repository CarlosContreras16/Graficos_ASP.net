﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Models
{

    class UsuarioModel
    {
        Vendor.ORM orm = new Vendor.ORM();
        Vendor.Helpers h = new Vendor.Helpers();

        public bool MakeLogin(string username, string password)
        {
            bool response = false;
            string condition = "USERNAME='" + username + "'";
            DataTable Data = orm.Find("USUARIOS", "*", condition);

            if (Data.Rows.Count > 0)
            {
                DataRow info = Data.Rows[0];
                string usuario = info["USERNAME"].ToString();
                string clave = info["PASSWORD"].ToString();
                string estado = info["ESTADO"].ToString();

                if (username == usuario && password == clave && estado == "ACTIVA")
                {
                    Vendor.Auth.USERNAME = username;
                    Vendor.Auth.REALNAME = info["NOMBRE"].ToString();
                    Vendor.Auth.ROLE = info["ROL"].ToString();
                    SetPrivileges(username);
                    response = true;
                }
                else
                {
                    h.Warning("EL USUARIO QUE INGRESO PARECE SER INCORRECTO");
                }
            }
            else
            {
                h.Warning("El USUARIO QUE INGRESO NO EXISTE!");
            }
            Data.Dispose();
            return response;
        }
        public void SetPrivileges(string username)
        {
            DataTable permisos = orm.Find("PERMISOS", "*", "USERNAME='" + username + "'");
            if (permisos.Rows.Count > 0)
            {
                DataRow info = permisos.Rows[0];
                Vendor.Auth.GUARDAR = info["GUARDAR"].ToString();
                Vendor.Auth.ACTUALIZAR = info["ACTUALIZAR"].ToString();
                Vendor.Auth.ELIMINAR = info["ELIMINAR"].ToString();
                Vendor.Auth.IMPRIMIR = info["IMPRIMIR"].ToString();
                Vendor.Auth.REIMPRIMIR = info["REIMPRIMIR"].ToString();
            }
            else
            {
                h.Warning("ERROR AL CARGAR LOS PERMISOS DEL USUARIO");
                Application.Exit();
            }

        }

        public bool GetInfoUsuario(string username)
        {
            bool response = true;
            DataTable informacion = orm.Find("USUARIOS", "NOMBRE, SEXO, FECHANAC, CORREO", "USERNAME='" + username + "'");
            if (informacion.Rows.Count > 0)
            {
                DataRow info = informacion.Rows[0];
                Program.Nombre = info["NOMBRE"].ToString();
                Program.Sexo = info["SEXO"].ToString();
                Program.Fechanac = info["FECHANAC"].ToString();
                Program.Correo = info["CORREO"].ToString();

                return response;
            }
            else
            {
                response = false;
            }
            return response;
        }
        public bool ModificarUsuario(string nombre, string sexo, DateTime fecha, string correo)
        {
            bool response = true;

            string data = "USERNAME='" + Vendor.Auth.USERNAME + "'";
            string condition = "NOMBRE='" + nombre + "', SEXO='" + sexo + "', FECHANAC='" + fecha + "', CORREO='" + correo + "'";

            try
            {
                if (orm.Update("USUARIOS", condition, data) > 0)
                {
                    h.MsgSuccess("DATOS DEL USUARIO ACTUALIZADOS CORRECTAMENTE");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }

            return response;
        }

        public bool ModificarClave(string contraseña)
        {
            bool response = true;

            string data = "USERNAME='" + Vendor.Auth.USERNAME + "'";
            string condition = "PASSWORD='" + contraseña + "'";

            try
            {
                if (orm.Update("USUAURIOS", data, condition) > 0)
                {
                    h.MsgSuccess("CONTRASEÑA DEL USUARIO ACTUALIZADOS CORRECTAMENTE");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }

            return response;
        }

        public bool VerificarPass(string pass, string contra)
        {
            bool response = true;

            string newc = "PASSWORD='" + contra + "'";
            string condition = "USERNAME='" + Vendor.Auth.USERNAME + "'";

            DataTable Data = orm.Find("USUARIOS", "*", condition);

            try
            {
                if (Data.Rows.Count > 0)
                {
                    DataRow info = Data.Rows[0];
                    string clave = info["PASSWORD"].ToString();

                    if (clave == pass)
                    {
                        string value = "PASSWORD='" + pass + "'";
                        orm.Update("USUARIOS", newc, value);
                        h.MsgSuccess("CONTRASEÑA ACTUALIZADA");
                        return response;
                    }
                    else
                    {
                        h.Warning("CONTRASEÑA INCORRECTA");
                    }
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.Message);
                response = false;
            }

            return response;
        }
    }
}
