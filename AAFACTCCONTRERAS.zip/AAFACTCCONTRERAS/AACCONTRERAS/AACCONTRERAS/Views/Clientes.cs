﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Views
{
    public partial class Clientes : Form
    {
        Controlles.ClientesController cc = new Controlles.ClientesController();
        Vendor.ORM orm = new Vendor.ORM();
        Vendor.Helpers h = new Vendor.Helpers();

        string idcorre = "CLIET";
        public Clientes()
        {
            InitializeComponent();
        }

        private void StarForm()
        {
            TxtCodigo.Enabled = false;
            TxtRtn.Enabled = false;
            TxtCliente.Enabled = false;
            TxtDireccion.Enabled = false;
            TxtTel.Enabled = false;
            TxtMovil.Enabled = false;
            TxtTipo.Enabled = false;
            TxtDireccion.Enabled = false;
            TxtCorreo.Enabled = false;
            TxtBuscar.Select();


            //botones del toolstrip
            BtnNuevo.Enabled = true;
            BtnGuardar.Enabled = false;
            BtnEditar.Enabled = false;
            BtnCancelar.Enabled = false;
            BtnSalir.Enabled = true;
            BtnEliminar.Enabled = false;
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }


        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void Clientes_Load(object sender, EventArgs e)
        {
            this.Text = Env.APPNAME + " | REGISTRO DE CLIENTES | " + Vendor.Auth.USERNAME + " | " + Vendor.Auth.ROLE;
            cc.MostrarCientes(DgvClientes);
            LimpiarControles();
            Boot();
        }
        public void NewCodCliente()
        {
            TxtCodigo.Text = "CLI" + cc.NewIdCliente(idcorre);
        }
        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            NewCodCliente();
            BtnGuardar.Enabled = Vendor.Auth.GUARDAR == "S" ? true : false;
            BtnCancelar.Enabled = true;

            ActivarControles();
        }
        private void Boot()
        {
            BtnNuevo.Enabled = Vendor.Auth.GUARDAR == "S" ? true : false;
            BtnGuardar.Enabled = false;
            BtnEditar.Enabled = false;
            BtnEliminar.Enabled = false;
            BtnCancelar.Enabled = false;
            BtnSalir.Enabled = true;

            TxtCodigo.Enabled = false;
            TxtRtn.Enabled = false;
            TxtCliente.Enabled = false;
            TxtDireccion.Enabled = false;
            TxtTel.Enabled = false;
            TxtMovil.Enabled = false;
            TxtTipo.Enabled = false;
            TxtDireccion.Enabled = false;
            TxtCorreo.Enabled = false;
            TxtBuscar.Select();
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Clean()
        {
            TxtCodigo.Clear();
            TxtRtn.Clear();
            TxtCliente.Clear();
            TxtDireccion.Clear();
            TxtTel.Clear();
            TxtMovil.Clear();
            TxtTipo.Clear();
            TxtDireccion.Clear();
            TxtCorreo.Clear();
            TxtBuscar.Clear();

        }
        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Boot();
            LimpiarControles();
        }

        public void ActivarControles()
        {
            foreach (TextBox txt in this.Controls.OfType<TextBox>())
            {
                txt.Enabled = true;
            }
            foreach (MaskedTextBox mask in this.Controls.OfType<MaskedTextBox>())
            {
                mask.Enabled = true;
            }
        }
        public void LimpiarControles()
        {
            foreach (TextBox txt in this.Controls.OfType<TextBox>())
            {
                txt.Clear();
            }
            foreach (MaskedTextBox mask in this.Controls.OfType<MaskedTextBox>())
            {
                mask.Clear();
            }
        }
        private void TstOpciones_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            cc.InsertCliente(TxtCodigo.Text, TxtRtn.Text, TxtCliente.Text, TxtDireccion.Text, TxtTel.Text, TxtMovil.Text, DtFechaNac.Value, TxtTipo.Text, TxtCorreo.Text);
            UpdateIdCliente();
            cc.MostrarCientes(DgvClientes);
            Boot();
            LimpiarControles();
        }
        private void UpdateIdCliente()
        {
            cc.UpdateCodCliente(idcorre, TxtRtn.Text, TxtCliente.Text, TxtDireccion.Text, TxtTel.Text, TxtMovil.Text, TxtTipo.Text, TxtCorreo.Text);
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            cc.EditarCliente(TxtCodigo.Text, TxtRtn.Text, TxtCliente.Text, TxtDireccion.Text, TxtTel.Text, TxtMovil.Text, DtFechaNac.Value, TxtTipo.Text, TxtCorreo.Text);
            cc.MostrarCientes(DgvClientes);
            LimpiarControles();
            Boot();
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            string msg = "¿Eliminar el cliente seleccionado";
            if (h.MsgQuestion(msg) == "S")
            {
                if (cc.EliminarCliente(TxtCodigo.Text) == true)
                {
                    h.MsgSuccess("EL CLIENTE SE ELIMINO CORRECTAMENTE");
                    cc.MostrarCientes(DgvClientes);
                    LimpiarControles();
                    Boot();
                }
            }
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            cc.BuscarCliente(DgvClientes, TxtBuscar.Text);
        }

        private void DgvClientes_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (DgvClientes.Rows.Count > 0)
            {
                string codprod = DgvClientes.CurrentRow.Cells[0].Value.ToString();
                GetInfoClientes(codprod);
            }
        }
        private void GetInfoClientes(string codprd)
        {
            BtnNuevo.Enabled = false;
            BtnGuardar.Enabled = false;
            BtnEditar.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
            BtnEliminar.Enabled = Vendor.Auth.ELIMINAR == "S" ? true : false;
            BtnCancelar.Enabled = true;
            BtnSalir.Enabled = true;
            string condicion = "IDCLIENTE='" + codprd + "'";
            DataTable data = orm.Find("CLIENTES", "*", condicion);
            if (data.Rows.Count > 0)
            {
                DataRow info = data.Rows[0];
                TxtCodigo.Text = info["IDCLIENTE"].ToString();
                TxtRtn.Text = info["RTN"].ToString();
                TxtCliente.Text = info["CLIENTE"].ToString();
                TxtDireccion.Text = info["DIRECCION"].ToString();
                TxtTel.Text = info["TELEFONO"].ToString();
                TxtMovil.Text = info["TELMOVIL"].ToString();
                DtFechaNac.Text = info["FECHANAC"].ToString();
                TxtTipo.Text = info["TIPO"].ToString();
                TxtCorreo.Text = info["CORREO"].ToString();

                TxtCodigo.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                TxtRtn.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                TxtCliente.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                TxtDireccion.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                TxtTel.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                TxtMovil.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                DtFechaNac.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                TxtTipo.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                TxtCorreo.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;      
            }
            else
            {
                h.Warning("ERROR AL RECUPERAR LOS DATOS DEL CLIENTE SELECCIONADO!");
            }
        }
    }
}
