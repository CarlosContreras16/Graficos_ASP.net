﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS
{
    static class Program
    {
        public static string CodProducto;
        public static string Producto;
        public static string Nombre;
        public static string Sexo;
        public static string Correo;
        public static string Fechanac;
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Views.Usuarios.LoginView());
        }
    }
}
