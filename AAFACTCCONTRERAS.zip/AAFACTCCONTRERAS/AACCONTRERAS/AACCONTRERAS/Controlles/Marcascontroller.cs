﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace AACCONTRERAS.Controlles
{
    class Marcascontroller
    {
        Vendor.Helpers h = new Vendor.Helpers();
        Vendor.ORM orm = new Vendor.ORM();
        Models.MarcasProdModel um = new Models.MarcasProdModel();

        public bool InsertMarca(string idmar, string marc)
        {
            bool response = true;
            string id = h.Clean(idmar.Trim());
            string marca = h.Clean(marc.Trim());
            string errors="";

            if (id.Length==0)
            {
                errors = "INGRESAR CODIGO\n";
                response = false;
            }
            if (marca.Length==0)
            {
                errors += "INGRESAR CATEGORIA";
                response = false;
            }
            if (response==false)
            {
                h.Warning(errors);
            }
            else
            {
                response = um.InsertMarcas(id, marca);
            }
            return response;
        }


        public bool EditarMarca(string idmar, string marca)
        {
            bool response = true;
            string id = h.Clean(idmar.Trim());
            string marc = h.Clean(marca.Trim());
            string errors = "";

            if (id.Length == 0)
            {
                errors = "INGRESAR CODIGO";
                response = false;
            }
            if (marc.Length == 0)
            {
                errors += "INGRESAR CATEGORIA";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = um.UpdateMarca(id, marc);
            }
            return response;
        }

        public bool EliminarMarca(string idmarc)
        {
            bool response = true;
            string id = h.Clean(idmarc.Trim());
            string errors = "";

            if (id.Length == 0)
            {
                errors = "INGRESAR CODIGO";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = um.DeleteMarcas(id);
            }
            return response;
        }

        public bool MostrarMarcas(DataGridView dgv)
        {
            bool response = true;

            if (response==false)
            {
                h.Warning("Error");
            }
            else
            {
                response = um.ShowMarcas(dgv);
            }
            return response;
        }
        public bool BuscarMarca(DataGridView dgv, string buscar)
        {
            bool response = true;
            if (response == false)
            {
                h.Warning("Error");
            }
            else
            {
                response = um.BuscarMarca(dgv, buscar);
            }
            return response;
        }

        public string NewIdMarca(string idcorre)
        {
            string id = "";
            id = um.NewIdMarca(idcorre);

            return id;
        }

        public void UpdateIdMarca(string id, string marca)
        {
            if (marca.Length==0)
            {
                return;
            }
            else
            {
                um.UpdateIdMarca(id);
            }
           
        }
    }
}
