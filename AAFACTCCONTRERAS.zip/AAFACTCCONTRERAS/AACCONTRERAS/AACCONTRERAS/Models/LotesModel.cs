﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;

namespace AACCONTRERAS.Models
{
    class LotesModel
    {
        Vendor.ORM orm = new Vendor.ORM();
        Vendor.Helpers h = new Vendor.Helpers();
        public bool InsertLote(string codbarra, string costo, string stock)
        {
            bool response = false;

            string condition = "CODBARRAS, COSTO, STOCK";
            string values = "'" + codbarra + "', '" + costo + "','" + stock + "'";

            try
            {
                if (orm.Save("LOTES", condition, values) > 0)
                {
                    h.MsgSuccess("El lote ha sido ingresado correctamente");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }

            return response;
        }
        public bool ShowLotes(string cod, DataGridView dgv)
        {
            string codbarra, fecha, costo, stock;
            bool response = false;
            DataTable registros;
            registros = new DataTable();
            registros = orm.Find("LOTES", "CODBARRAS, FECHA, COSTO, STOCK", "CODBARRAS='"+cod+"'", "FECHA");
            if (registros.Rows.Count > 0)
            {
                dgv.Rows.Clear();
                int i;
                for (i = 0; i < registros.Rows.Count; i++)
                {
                    codbarra = registros.Rows[i][0].ToString();
                    fecha = registros.Rows[i][1].ToString();
                    costo = registros.Rows[i][2].ToString();
                    stock = registros.Rows[i][3].ToString();
                    dgv.Rows.Add(codbarra, fecha, costo, stock);
                }
            }
            return response;
        }
    }
}
