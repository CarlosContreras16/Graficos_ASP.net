﻿
namespace AACCONTRERAS.Views.Configuracion
{
    partial class RegistrarCai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistrarCai));
            this.label1 = new System.Windows.Forms.Label();
            this.TxtRtn = new System.Windows.Forms.TextBox();
            this.TxtNombre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TxtCai = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.DtFechaLimite = new System.Windows.Forms.DateTimePicker();
            this.TxtPrefijo = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TxtFacInicial = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TxtFacturaIni = new System.Windows.Forms.TextBox();
            this.TxtFacturaFin = new System.Windows.Forms.TextBox();
            this.TxtFacFinal = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.DtFechaFin = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.LblEstado = new System.Windows.Forms.Label();
            this.CbEstado = new System.Windows.Forms.ComboBox();
            this.BtnGuardar = new System.Windows.Forms.Button();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "RTN:";
            // 
            // TxtRtn
            // 
            this.TxtRtn.BackColor = System.Drawing.Color.White;
            this.TxtRtn.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRtn.Location = new System.Drawing.Point(166, 10);
            this.TxtRtn.Name = "TxtRtn";
            this.TxtRtn.ReadOnly = true;
            this.TxtRtn.Size = new System.Drawing.Size(131, 24);
            this.TxtRtn.TabIndex = 1;
            // 
            // TxtNombre
            // 
            this.TxtNombre.BackColor = System.Drawing.Color.White;
            this.TxtNombre.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNombre.Location = new System.Drawing.Point(166, 39);
            this.TxtNombre.Name = "TxtNombre";
            this.TxtNombre.ReadOnly = true;
            this.TxtNombre.Size = new System.Drawing.Size(318, 24);
            this.TxtNombre.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "NOMBRE O RAZON:";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(-2, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(285, 26);
            this.label3.TabIndex = 4;
            this.label3.Text = "   Ingresar los datos del nuevo Cais";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TxtCai
            // 
            this.TxtCai.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCai.Location = new System.Drawing.Point(160, 120);
            this.TxtCai.Name = "TxtCai";
            this.TxtCai.Size = new System.Drawing.Size(131, 24);
            this.TxtCai.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 125);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "CAI:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(18, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "FECHA LIMITE EM:";
            // 
            // DtFechaLimite
            // 
            this.DtFechaLimite.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DtFechaLimite.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DtFechaLimite.Location = new System.Drawing.Point(160, 150);
            this.DtFechaLimite.Name = "DtFechaLimite";
            this.DtFechaLimite.Size = new System.Drawing.Size(152, 24);
            this.DtFechaLimite.TabIndex = 8;
            // 
            // TxtPrefijo
            // 
            this.TxtPrefijo.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPrefijo.Location = new System.Drawing.Point(160, 180);
            this.TxtPrefijo.Name = "TxtPrefijo";
            this.TxtPrefijo.Size = new System.Drawing.Size(131, 24);
            this.TxtPrefijo.TabIndex = 10;
            this.TxtPrefijo.TextChanged += new System.EventHandler(this.TxtPrefijo_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 187);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 16);
            this.label6.TabIndex = 9;
            this.label6.Text = "PREFIJO:";
            // 
            // TxtFacInicial
            // 
            this.TxtFacInicial.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFacInicial.Location = new System.Drawing.Point(160, 211);
            this.TxtFacInicial.Name = "TxtFacInicial";
            this.TxtFacInicial.Size = new System.Drawing.Size(131, 24);
            this.TxtFacInicial.TabIndex = 12;
            this.TxtFacInicial.TextChanged += new System.EventHandler(this.TxtFacInicial_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 217);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 16);
            this.label7.TabIndex = 11;
            this.label7.Text = "FACTURA INICIAL:";
            // 
            // TxtFacturaIni
            // 
            this.TxtFacturaIni.BackColor = System.Drawing.Color.White;
            this.TxtFacturaIni.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFacturaIni.Location = new System.Drawing.Point(297, 211);
            this.TxtFacturaIni.Name = "TxtFacturaIni";
            this.TxtFacturaIni.ReadOnly = true;
            this.TxtFacturaIni.Size = new System.Drawing.Size(209, 24);
            this.TxtFacturaIni.TabIndex = 13;
            // 
            // TxtFacturaFin
            // 
            this.TxtFacturaFin.BackColor = System.Drawing.Color.White;
            this.TxtFacturaFin.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFacturaFin.Location = new System.Drawing.Point(297, 241);
            this.TxtFacturaFin.Name = "TxtFacturaFin";
            this.TxtFacturaFin.ReadOnly = true;
            this.TxtFacturaFin.Size = new System.Drawing.Size(209, 24);
            this.TxtFacturaFin.TabIndex = 16;
            // 
            // TxtFacFinal
            // 
            this.TxtFacFinal.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFacFinal.Location = new System.Drawing.Point(160, 241);
            this.TxtFacFinal.Name = "TxtFacFinal";
            this.TxtFacFinal.Size = new System.Drawing.Size(131, 24);
            this.TxtFacFinal.TabIndex = 15;
            this.TxtFacFinal.TextChanged += new System.EventHandler(this.TxtFacFinal_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(17, 247);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 16);
            this.label8.TabIndex = 14;
            this.label8.Text = "FACTURA FINAL:";
            // 
            // DtFechaFin
            // 
            this.DtFechaFin.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DtFechaFin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DtFechaFin.Location = new System.Drawing.Point(160, 271);
            this.DtFechaFin.Name = "DtFechaFin";
            this.DtFechaFin.Size = new System.Drawing.Size(152, 24);
            this.DtFechaFin.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(18, 278);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 16);
            this.label9.TabIndex = 17;
            this.label9.Text = "FECHA DE RECEP:";
            // 
            // LblEstado
            // 
            this.LblEstado.AutoSize = true;
            this.LblEstado.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEstado.Location = new System.Drawing.Point(18, 310);
            this.LblEstado.Name = "LblEstado";
            this.LblEstado.Size = new System.Drawing.Size(63, 16);
            this.LblEstado.TabIndex = 19;
            this.LblEstado.Text = "ESTADO:";
            // 
            // CbEstado
            // 
            this.CbEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbEstado.FormattingEnabled = true;
            this.CbEstado.Items.AddRange(new object[] {
            "ACTIVO",
            "VENCIDO"});
            this.CbEstado.Location = new System.Drawing.Point(160, 302);
            this.CbEstado.Name = "CbEstado";
            this.CbEstado.Size = new System.Drawing.Size(111, 27);
            this.CbEstado.TabIndex = 20;
            this.CbEstado.Visible = false;
            // 
            // BtnGuardar
            // 
            this.BtnGuardar.Image = ((System.Drawing.Image)(resources.GetObject("BtnGuardar.Image")));
            this.BtnGuardar.Location = new System.Drawing.Point(76, 355);
            this.BtnGuardar.Name = "BtnGuardar";
            this.BtnGuardar.Size = new System.Drawing.Size(100, 34);
            this.BtnGuardar.TabIndex = 21;
            this.BtnGuardar.Text = "Guardar";
            this.BtnGuardar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.BtnGuardar.UseVisualStyleBackColor = true;
            this.BtnGuardar.Click += new System.EventHandler(this.BtnGuardar_Click);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("BtnCancelar.Image")));
            this.BtnCancelar.Location = new System.Drawing.Point(189, 355);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(108, 34);
            this.BtnCancelar.TabIndex = 22;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.BtnCancelar.UseVisualStyleBackColor = true;
            // 
            // RegistrarCai
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(544, 415);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.BtnGuardar);
            this.Controls.Add(this.CbEstado);
            this.Controls.Add(this.LblEstado);
            this.Controls.Add(this.DtFechaFin);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.TxtFacturaFin);
            this.Controls.Add(this.TxtFacFinal);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.TxtFacturaIni);
            this.Controls.Add(this.TxtFacInicial);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TxtPrefijo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.DtFechaLimite);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TxtCai);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TxtNombre);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TxtRtn);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Name = "RegistrarCai";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RegistrarCai";
            this.Load += new System.EventHandler(this.RegistrarCai_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtRtn;
        private System.Windows.Forms.TextBox TxtNombre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TxtCai;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker DtFechaLimite;
        private System.Windows.Forms.TextBox TxtPrefijo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TxtFacInicial;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TxtFacturaIni;
        private System.Windows.Forms.TextBox TxtFacturaFin;
        private System.Windows.Forms.TextBox TxtFacFinal;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker DtFechaFin;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label LblEstado;
        private System.Windows.Forms.ComboBox CbEstado;
        private System.Windows.Forms.Button BtnGuardar;
        private System.Windows.Forms.Button BtnCancelar;
    }
}