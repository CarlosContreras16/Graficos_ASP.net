﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Controlles
{
    class CaisController
    {

        Vendor.Helpers h = new Vendor.Helpers();
        Vendor.ORM orm = new Vendor.ORM();
        Models.RegistrarCaisModel cm = new Models.RegistrarCaisModel();

        public bool InsertCais(string refcai, string cai, DateTime fechal, string pref, string factini, string factfin, DateTime fecharec, string usuario)
        {
            bool response = true;
            string id = h.Clean(refcai.Trim());
            string cais = h.Clean(cai.Trim());
            string pre = h.Clean(pref.Trim());
            string faini = h.Clean(factini.Trim());
            string fafin = h.Clean(factfin.Trim());
            string usu = h.Clean(usuario.Trim());
            string errors = "";

            if (id.Length == 0)
            {
                errors = "INGRESAR CODIGO\n";
                response = false;
            }
            if (cais.Length == 0)
            {
                errors += "INGRESAR CAI";
                response = false;
            }
            if (pre.Length == 0)
            {
                errors += "INGRESAR PREFIJO";
                response = false;
            }
            if (faini.Length == 0)
            {
                errors += "INGRESAR FACTURA INICIAL";
                response = false;
            }
            if (fafin.Length == 0)
            {
                errors += "INGRESAR FACTRURA FINAL";
                response = false;
            }
            if (usu.Length == 0)
            {
                errors += "INGRESAR USUARIO";
                response = false;
            }

            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = cm.InsertCais(id, cais, fechal, pre, faini, fafin, fecharec, usu);
            }
            return response;
        }
        public bool EditarCais(string refcai, string cai, DateTime fechal, string pref, string factini, string factfin, DateTime fecharec, string usuario)
        {
            bool response = true;
            string id = h.Clean(refcai.Trim());
            string cais = h.Clean(cai.Trim());
            string pre = h.Clean(pref.Trim());
            string faini = h.Clean(factini.Trim());
            string fafin = h.Clean(factfin.Trim());
            string usu = h.Clean(usuario.Trim());
            string errors = "";

            if (id.Length == 0)
            {
                errors = "INGRESAR CODIGO\n";
                response = false;
            }
            if (cais.Length == 0)
            {
                errors += "INGRESAR CAI";
                response = false;
            }
            if (pre.Length == 0)
            {
                errors += "INGRESAR PREFIJO";
                response = false;
            }
            if (faini.Length == 0)
            {
                errors += "INGRESAR FACTURA INICIAL";
                response = false;
            }
            if (fafin.Length == 0)
            {
                errors += "INGRESAR FACTRURA FINAL";
                response = false;
            }
            if (usu.Length == 0)
            {
                errors += "INGRESAR USUARIO";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = cm.UpdateCais(id, cais, fechal, pre, faini, fafin, fecharec, usu);
            }
            return response;
        }

        public bool EliminarCategoria(string value)
        {
            bool response = true;
            string val = h.Clean(value.Trim());
            string errors = "";
            if (val.Length == 0)
            {
                errors += "INGRESAR CATEGORIA";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = cm.DeleteCategoria(val);
            }
            return response;
        }
        public bool MostrarCais(DataGridView dgv)
        {
            bool response = true;

            if (response == false)
            {
                h.Warning("Error");
            }
            else
            {
                response = cm.ShowCais(dgv);
            }
            return response;
        }
        public bool Buscarcat(DataGridView dgv)
        {
            bool response = true;
            if (response == false)
            {
                h.Warning("Error");
            }
            else
            {
                response = cm.ShowCais(dgv);
            }
            return response;
        }
        public string NewIdCate(string idcorre)
        {
            string id = "";
            id = cm.NewIdCate(idcorre);

            return id;
        }

        public void UpdateIdCate(string id, string marca)
        {
            if (marca.Length == 0)
            {
                return;
            }
            else
            {
                cm.UpdateIdCate(id);
            }
        }
    }
}
