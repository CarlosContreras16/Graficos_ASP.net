﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Views
{
    public partial class MarcasProducto : Form
    {
        Controlles.Marcascontroller mc = new Controlles.Marcascontroller();

        string idcorre = "MARCS";
        public MarcasProducto()
        {
            InitializeComponent();
        }

        private void MarcasProducto_Load(object sender, EventArgs e)
        {
            this.Text = Env.APPNAME + " MARCAS DE LOS PRODUCTOS";
            StarForm();
            mc.MostrarMarcas(DgvMarcasProd);
        }

        private void Clean()
        {
            TxtIdMarca.Clear();
            TxtMarca.Clear();
        }

        private void StarForm()
        {
            TxtIdMarca.Enabled = false;
            TxtMarca.Enabled = false;

            BtnGuardar.Enabled = false;
            BtnNuevo.Enabled = true;
            BtnEditar.Enabled = false;
            BtnCancelar.Enabled = false;
            BtnSalir.Enabled = true;
            BtnEliminar.Enabled = false;
        }

        public void IdMarcaNuevo()
        {
            TxtIdMarca.Text = "MRC" + mc.NewIdMarca(idcorre);
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            TxtIdMarca.Clear();
            TxtMarca.Clear();
            IdMarcaNuevo();
            TxtIdMarca.Enabled = false;
            TxtMarca.Enabled = true;
            TxtMarca.Focus();

            BtnNuevo.Enabled = true;
            BtnGuardar.Enabled = Vendor.Auth.GUARDAR == "S" ? true : false;
            BtnEditar.Enabled = false;
            BtnCancelar.Enabled = true;
            BtnSalir.Enabled = true;
            BtnEliminar.Enabled = true;
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            StarForm();
            TxtMarca.Clear();
            IdMarcaNuevo();
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TstOpciones_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            mc.InsertMarca(TxtIdMarca.Text, TxtMarca.Text);
            mc.MostrarMarcas(DgvMarcasProd);
            mc.UpdateIdMarca(idcorre, TxtMarca.Text);
            Clean();
            IdMarcaNuevo();
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            mc.EditarMarca(TxtIdMarca.Text, TxtMarca.Text);
            mc.MostrarMarcas(DgvMarcasProd);
            Clean();
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            mc.EliminarMarca(TxtIdMarca.Text);
            mc.MostrarMarcas(DgvMarcasProd);
            Clean();
        }

        private void DgvMarcasProd_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridView dgv1 = DgvMarcasProd;

                TxtIdMarca.Text = Convert.ToString(dgv1.CurrentRow.Cells[0].Value);
                TxtMarca.Text = Convert.ToString(dgv1.CurrentRow.Cells[1].Value);
            }

            TxtMarca.Enabled = true;
            BtnGuardar.Enabled = false;
            BtnCancelar.Enabled = true;
            BtnEditar.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
            BtnEliminar.Enabled = Vendor.Auth.ELIMINAR == "S" ? true : false;
        }

        private void TxtBuscar_TextChanged(object sender, EventArgs e)
        {
            mc.BuscarMarca(DgvMarcasProd, TxtBuscar.Text);
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            mc.BuscarMarca(DgvMarcasProd, TxtBuscar.Text);
        }
    }
}
