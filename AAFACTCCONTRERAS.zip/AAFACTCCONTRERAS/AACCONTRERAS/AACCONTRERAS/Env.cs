﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AACCONTRERAS
{
    class Env
    {
        public static string APPNAME = "PROYECTO ANALISIS DE ALGORITMOS | ";

        public static string SERVER = "DESKTOP-KEPHBQ4\\SQLEXPRESS";
        public static string USER = "CarlosContreras";
        public static string PASS = "12345";
        public static string DATABASE = "AAFACTCCONTRERAS";
        public static string USEROS = "Carlos Contreras";
        public static string HOST = "SERVER";

        public static string ENV="DEV";
    }
}
