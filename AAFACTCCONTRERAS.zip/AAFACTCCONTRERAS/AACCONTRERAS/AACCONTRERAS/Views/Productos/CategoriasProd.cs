﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Views
{
    public partial class CategoriasProd : Form
    {
        Controlles.CategoriaController cc = new Controlles.CategoriaController();

        string idcorre = "CATRS";
        public CategoriasProd()
        {
            InitializeComponent();
        }
        private void CategoriasProd_Load(object sender, EventArgs e)
        {
            this.Text = Env.APPNAME + " CATEGORIAS DE LOS PRODUCTOS";
            StarForm();
            cc.MostrarCategorias(DgvCateProd);
        }
        private void Clean()
        {
            TxtIdCate.Clear();
            TxtCategoria.Clear();
        }

        private void StarForm()
        {
            TxtIdCate.Enabled = false;
            TxtCategoria.Enabled = false;

            BtnNuevo.Enabled = true;
            BtnGuardar.Enabled = false;
            BtnEditar.Enabled = false;
            BtnCancelar.Enabled = false;
            BtnSalir.Enabled = true;
            BtnEliminar.Enabled = false;
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            cc.InsertCategoria(TxtIdCate.Text, TxtCategoria.Text);
            cc.MostrarCategorias(DgvCateProd);
            cc.UpdateIdCate(idcorre, TxtCategoria.Text);
            Clean();
            
            StarForm();
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            cc.EditarCategoria(TxtIdCate.Text, TxtCategoria.Text);
            cc.MostrarCategorias(DgvCateProd);
            Clean();
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            cc.EliminarCategoria(TxtIdCate.Text);
            cc.MostrarCategorias(DgvCateProd);
            Clean();
        }

        private void TxtBuscar_TextChanged(object sender, EventArgs e)
        {
            cc.Buscarcat(DgvCateProd, TxtBuscar.Text);
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            cc.Buscarcat(DgvCateProd, TxtBuscar.Text);
        }

        private void DgvCateProd_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridView dgv1 = DgvCateProd;
                TxtIdCate.Text = Convert.ToString(dgv1.CurrentRow.Cells[0].Value);
                TxtCategoria.Text = Convert.ToString(dgv1.CurrentRow.Cells[1].Value);

            }

            TxtCategoria.Enabled = true;
            BtnGuardar.Enabled = false;
            BtnCancelar.Enabled = true;
            BtnEditar.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
            BtnEliminar.Enabled = Vendor.Auth.ELIMINAR == "S" ? true : false;
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Clean();
            TxtCategoria.Clear();
            IdCateNuevo();
            StarForm();
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            TxtIdCate.Clear();
            TxtCategoria.Clear();
            TxtIdCate.Enabled = false;
            IdCateNuevo();
            TxtCategoria.Enabled = true;
            TxtCategoria.Focus();

            BtnGuardar.Enabled = Vendor.Auth.GUARDAR == "S" ? true : false;
            BtnCancelar.Enabled = true;
        }
        public void IdCateNuevo()
        {
            TxtIdCate.Text = "CAT" + cc.NewIdCate(idcorre);
        }
    }
}
