﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace AACCONTRERAS.Controlles
{
    class ConfiguracionController
    {
        Vendor.Helpers h = new Vendor.Helpers();
        Vendor.ORM orm = new Vendor.ORM();
        Models.ConfiguracionModel cm = new Models.ConfiguracionModel();

        public bool InsertConfiguacion(string rtn, string nombreorazon, string direccion, string ciudad, string telefonos, string correo, string website, string logo)
        {
            bool response = true;
            string nombre = h.Clean(nombreorazon.Trim());
            string dir = h.Clean(direccion.Trim());
            string ciud = h.Clean(ciudad.Trim());
            string tel = h.Clean(telefonos.Trim());
            string correos = h.Clean(correo.Trim());
            string web = h.Clean(website.Trim());
            string log = h.Clean(logo.Trim());
            string errors = "";

            if (rtn.Length == 0)
            {
                errors = "INGRESAR RTN\n";
                response = false;
            }
            if (nombre.Length == 0)
            {
                errors += "INGRESAR NOMBRE";
                response = false;
            }
            if (dir.Length == 0)
            {
                errors += "INGRESAR DIRECCION";
                response = false;
            }
            if (ciud.Length == 0)
            {
                errors += "INGRESAR CIUDAD";
                response = false;
            }
            if (tel.Length == 0)
            {
                errors += "INGRESAR TELEFONO";
                response = false;
            }
            if (correos.Length == 0)
            {
                errors += "INGRESAR CORREO";
                response = false;
            }
            if (web.Length == 0)
            {
                errors += "INGRESAR SITIO WEB";
                response = false;
            }
            if (log.Length == 0)
            {
                errors += "INGRESAR LOGO";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = cm.InsertConfi(rtn, nombre, dir, ciud, tel, correos, web, log);
            }
            return response;
        }
        public bool UpdateConfiguacion(string rtn, string nombreorazon, string direccion, string ciudad, string telefonos, string correo, string website, string logo)
        {
            bool response = true;
            string nombre = h.Clean(nombreorazon.Trim());
            string dir = h.Clean(direccion.Trim());
            string ciud = h.Clean(ciudad.Trim());
            string tel = h.Clean(telefonos.Trim());
            string correos = h.Clean(correo.Trim());
            string web = h.Clean(website.Trim());
            string log = h.Clean(logo.Trim());
            string errors = "";

            if (rtn.Length == 0)
            {
                errors = "INGRESAR RTN\n";
                response = false;
            }
            if (nombre.Length == 0)
            {
                errors += "INGRESAR NOMBRE";
                response = false;
            }
            if (dir.Length == 0)
            {
                errors += "INGRESAR DIRECCION";
                response = false;
            }
            if (ciud.Length == 0)
            {
                errors += "INGRESAR CIUDAD";
                response = false;
            }
            if (tel.Length == 0)
            {
                errors += "INGRESAR TELEFONO";
                response = false;
            }
            if (correos.Length == 0)
            {
                errors += "INGRESAR CORREO";
                response = false;
            }
            if (web.Length == 0)
            {
                errors += "INGRESAR SITIO WEB";
                response = false;
            }
            if (log.Length == 0)
            {
                errors += "INGRESAR LOGO";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = cm.UpdateConfi(rtn, nombre, dir, ciud, tel, correos, web, log);
            }
            return response;
        }
        public bool EliminarConfiguracion(string value)
        {
            bool response = true;
            string val = h.Clean(value.Trim());
            string errors = "";
            if (val.Length == 0)
            {
                errors += "INGRESAR RTN";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = cm.DeleteConfi(val);
            }
            return response;
        }
        public bool MostrarConfiguracion(DataGridView dgv)
        {
            bool response = true;

            if (response == false)
            {
                h.Warning("Error");
            }
            else
            {
                response = cm.ShowConfi(dgv);
            }
            return response;
        }
    }
}
