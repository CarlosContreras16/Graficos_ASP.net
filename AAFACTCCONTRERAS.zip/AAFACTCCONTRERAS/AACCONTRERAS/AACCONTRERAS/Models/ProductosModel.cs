﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Models
{
    class ProductosModel
    {
        Vendor.ORM orm = new Vendor.ORM();
        Vendor.Helpers h = new Vendor.Helpers();

        public bool InsertProducto(string codbarras, string descripcion, string idcate, string idmarca, string fiscal, string isv, string tipoprod, string min, string idpresin, string idpresout, string increment, string preciodet, string preciomay, string stockmin)
        {
            bool response = false;
            string condition = "CODBARRAS, DESCRIPCION, IDCATE, IDMARCA, FISCAL, ISV, TIPOPROD, MINV, IDPRES_IN, IDPRES_OUT, INCREMENT, PRECIODET, PRECIOMAY, STOCKMIN";
            string values = "'" + codbarras + "', '" + descripcion + "','" + idmarca + "', '" + idcate + "', '" + fiscal + "', '" + isv + "', '" + tipoprod + "', '" + min + "', '" + idpresin + "', '" + idpresout + "', '" + increment + "', '" + preciodet + "', '" + preciomay + "', '" + stockmin + "'";

            try
            {
                if (orm.Save("PRODUCTOS", condition, values) > 0)
                {
                    h.MsgSuccess("El producto ha sido ingresado correctamente");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                ex.ToString();
            }
            return response;
        }

        public bool UpdateProducto(string codbarras, string descripcion, string idcate, string idmarca, string fiscal, string isv, string tipoprod, string min, string idpresin, string idpresout, string increment, string preciodet, string preciomay, string stockmin)
        {
            bool response = false;

            string data = "DESCRIPCION='" + descripcion + "', IDCATE='" + idcate + "', " +
                "IDMARCA='" + idmarca + "', FISCAL='" + fiscal + "', ISV='" + isv + "', TIPOPROD='" + tipoprod + "', MINV='" 
                + min + "', IDPRES_IN='" + idpresin + "', IDPRES_OUT='" + idpresout + "', INCREMENT='" + increment + "', PRECIODET='" + preciodet + "'" +
                ", PRECIOMAY='" + preciomay + "', STOCKMIN='" + stockmin + "'";
            string condition = "CODBARRAS = '" + codbarras + "'";

            if (orm.Update("PRODUCTOS", data, condition) > 0)
            {
                h.MsgSuccess("PRPDUCTO ACTUALIZADO CORRECTAMENTE");
                response = true;
            }
            else
            {
                h.Warning("ERROR AL ACTUALIZAR");
            }
            return response;
        }

        public bool DeleteProducto(string codbarra)
        {
            bool response = false;
            string condition = "CODBARRAS";
            string values = codbarra;

            if (orm.Delete("PRODUCTOS", condition, values) > 0)
            {
                h.MsgSuccess("PRODUCTO ELIMINADO CORRECTAMENTE");
                response = true;
            }

            return response;
        }

        public bool ShowProducto(DataGridView dgv)
        {
            bool response = false;

            string codbarras, descripcion, preciomay;
            DataTable Registros = new DataTable();
            Registros = orm.Find("PRODUCTOS", "CODBARRAS, DESCRIPCION, PRECIOMAY", "DEL<>'S'");
            try
            {
                if (Registros.Rows.Count > 0)
                {
                    dgv.Rows.Clear();
                    int i;
                    for (i = 0; i < Registros.Rows.Count; i++)
                    {
                        codbarras = Registros.Rows[i][0].ToString();
                        descripcion = Registros.Rows[i][1].ToString();
                        //idcate = Registros.Rows[i][2].ToString();
                        //idmarca = Registros.Rows[i][3].ToString();
                        //fiscal = Registros.Rows[i][4].ToString();
                        //isv = Registros.Rows[i][5].ToString();
                        //tipoprod = Registros.Rows[i][6].ToString();
                        //min = Registros.Rows[i][7].ToString();
                        //idpresin = Registros.Rows[i][8].ToString();
                        //idpresout = Registros.Rows[i][9].ToString();
                        //increment = Registros.Rows[i][10].ToString();
                        //preciodet = Registros.Rows[i][11].ToString();
                        preciomay = Registros.Rows[i][2].ToString();
                        //stockmin = Registros.Rows[i][13].ToString();
                        //confies = Registros.Rows[i][14].ToString();
                        //codpadre = Registros.Rows[i][15].ToString();
                        //nota = Registros.Rows[i][16].ToString();
                        dgv.Rows.Add(codbarras, descripcion, preciomay);
                    }
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }
            return response;
        }
        public bool BuscarProducto(DataGridView dgv, string buscar)
        {
            bool response = false;
            string codbarras, descripcion, idcate, idmarca, fiscal, isv, tipoprod, min, idpresin, idpresout, increment, preciodet, preciomay, stockmin, confies, codpadre, nota;
            DataTable Registros;
            Registros = new DataTable();
            
            string columns, condition;
            columns = "CODBARRAS, DESCRIPCION, IDCATE, IDMARCA, FISCAL, ISV, TIPOPROD, MINV, IDPRES_IN, IDPRES_OUT, INCREMENT, PRECIODET, PRECIOMAY, STOCKMIN, CONF_ESP, CODPRDPADRE, NOTA";
            condition = "CODBARRAS LIKE '%" + buscar + "%' OR DESCRIPCION LIKE '%" + buscar + "%'";
            Registros = orm.Find("CATEGORIASPRODUCTOS", columns, condition);
            
            if (Registros.Rows.Count > 0)
            {
                dgv.Rows.Clear();
                int i;
                for (i = 0; i < Registros.Rows.Count; i++)
                {
                    codbarras = Registros.Rows[i][0].ToString();
                    descripcion = Registros.Rows[i][1].ToString();
                    idcate = Registros.Rows[i][2].ToString();
                    idmarca = Registros.Rows[i][3].ToString();
                    fiscal = Registros.Rows[i][4].ToString();
                    isv = Registros.Rows[i][5].ToString();
                    tipoprod = Registros.Rows[i][6].ToString();
                    min = Registros.Rows[i][7].ToString();
                    idpresin = Registros.Rows[i][8].ToString();
                    idpresout = Registros.Rows[i][9].ToString();
                    increment = Registros.Rows[i][10].ToString();
                    preciodet = Registros.Rows[i][11].ToString();
                    preciomay = Registros.Rows[i][12].ToString();
                    stockmin = Registros.Rows[i][13].ToString();
                    confies = Registros.Rows[i][14].ToString();
                    codpadre = Registros.Rows[i][15].ToString();
                    nota = Registros.Rows[i][16].ToString();
                    dgv.Rows.Add(codbarras, descripcion, idcate, idmarca, fiscal, isv, tipoprod, min, idpresin, idpresout, increment, preciodet, preciomay, stockmin, confies, codpadre, nota);
                }
            }
            return response;
        }
        public void UpdateCodBarra(string idcorre)
        {
            orm.SetLast(idcorre);
        }
    }
}
