﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Controlles
{
    class LotesController
    {
        Vendor.Helpers h = new Vendor.Helpers();
        Vendor.ORM orm = new Vendor.ORM();
        Models.LotesModel lm = new Models.LotesModel();
        public bool InsertCategoria(string codbarra, string producto, string stock)
        {
            bool response = true;
            string cod = h.Clean(codbarra.Trim());
            string prod = h.Clean(producto.Trim());
            string stck = h.Clean(stock);
            string errors = "";

            if (cod.Length == 0)
            {
                errors = "INGRESAR CODIGO\n";
                response = false;
            }
            if (prod.Length == 0)
            {
                errors += "INGRESAR PRODUCTO\n";
                response = false;
            }
            if (stock.Length == 0)
            {
                errors += "INGRESAR STOCK";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = lm.InsertLote(cod, prod, stck);
            }
            return response;
        }
        public bool MostrarLotes(string cod, DataGridView dgv)
        {
            bool response = true;
            string errors = "";

            //if (cod.Length == 0)
            //{
            //    errors = "INGRESAR CODIGO";
            //    response = false;
            //}
            if (response == false)
            {
                h.Warning("Error");
            }
            else
            {
                response = lm.ShowLotes(cod, dgv);
            }
            return response;
        }
    }
}
