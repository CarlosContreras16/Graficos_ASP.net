﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AACCONTRERAS.Controlles
{
    class UsuarioController
    {
        Vendor.Helpers h = new Vendor.Helpers();
        Vendor.DataBase.Seeder seeder = new Vendor.DataBase.Seeder();
        Vendor.ORM orm = new Vendor.ORM();
        Models.UsuarioModel um = new Models.UsuarioModel();
        public bool Validate(string usernanme, string password)
        {
            bool response = true;
            string usuario = h.Clean(usernanme.Trim());
            string clave = h.Clean(password.Trim());
            string errors = "";

            if (usuario.Length==0)
            {
               errors = "INGRESAR NOMBRE DE USUARIO VALIDO!\n";
                response = false;
            }

            if (clave.Length==0)
            {
                errors += "INGRESE CLAVE DE ACCESO";
                response = false;
            }

            if (response==false)
            {
                h.Warning(errors);
            }
            else
            {
                response = um.MakeLogin(usuario, MakeHash(clave));
            }
            return response;
        }

        public void RegisterSuperUser()
        {
            seeder.SeederSuperUser(MakeHash("123456"));
        }

        public string MakeHash(string key)
        {
            string hash="";
            SHA512 sha512 = new SHA512CryptoServiceProvider();
            byte[] inputbytes = (new UnicodeEncoding().GetBytes(key));
            byte[] result = sha512.ComputeHash(inputbytes);
            hash = Convert.ToBase64String(result);
            return hash;
        }

        // Registro de usuarios Tester
        public void CreateUserTester()
        {
            seeder.CreateUserTester("Tester1", MakeHash("123456"),"CAJERO");
            seeder.CreateUserTester("Tester2", MakeHash("123456"),"VENDEDOR");
        }

        public bool GetInfoCliente(string nombre)
        {
          return um.GetInfoUsuario(nombre);
        }

        public bool ModificarUsuario(string nombre, string sexo, DateTime fecha, string correo)
        {
            bool response = true;
            string errors = "";
            if (nombre.Length == 0)
            {
                errors = "INGRESAR NOMBRE\n";
                response = false;
            }
            if (sexo.Length == 0)
            {
                errors += "INGRESAR SEXO\n";
                response = false;
            }
            if (correo.Length == 0)
            {
                errors += "INGRESAR CORREO\n";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else 
            {
                response = um.ModificarUsuario(nombre, sexo, fecha, correo);
            }

            return response;
        }
        public bool VerificarPass(string pass1, string pass2, string contra)
        {
            string clave = h.Clean(contra.Trim());
            string clave2 = h.Clean(pass1.Trim());
            bool response = true;
            string errors = "";
            if (pass2!=contra)
            {
                errors += "CONTRASEÑAS NO COINCIDEN\n";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                um.VerificarPass(MakeHash(clave2), MakeHash(contra));
            }

            return response;
        }
    }
}
