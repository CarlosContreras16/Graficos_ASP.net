﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Views.Configuracion
{
    public partial class ViewCais : Form
    {
        Controlles.CaisController cais = new Controlles.CaisController();
        public string rtn, nombre;
        public string com, idcai;
        public ViewCais()
        {
            InitializeComponent();
        }

        private void BtnRegistrarCai_Click(object sender, EventArgs e)
        {
            Configuracion.RegistrarCai regi = new RegistrarCai();
            regi.rtn = TxtRtn.Text.Trim();
            regi.razonsocial = TxtNombre.Text.Trim();
            regi.command = "NEW";
            this.AddOwnedForm(regi);
            regi.ShowDialog();
        }

        private void ViewCais_Load(object sender, EventArgs e)
        {
            TxtRtn.Text = rtn;
            TxtNombre.Text = nombre;
            GetCais();
        }

        private void ViewCais_Activated(object sender, EventArgs e)
        {
            
        }

        private void DgvCai_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (DgvCai.Rows.Count>0)
            {
                Configuracion.RegistrarCai regi = new RegistrarCai();
                regi.rtn = TxtRtn.Text.Trim();
                regi.razonsocial = TxtNombre.Text.Trim();
                regi.command = "OLD";
                regi.GetInfoCai(DgvCai.CurrentRow.Cells[0].Value.ToString());
                this.AddOwnedForm(regi);
                regi.ShowDialog();
            }
        }

        public void GetCais()
        {
            cais.MostrarCais(DgvCai);
        }
    }
}
