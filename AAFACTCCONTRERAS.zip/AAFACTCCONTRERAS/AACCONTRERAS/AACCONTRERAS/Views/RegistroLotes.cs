﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Views
{
    public partial class RegistroLotes : Form
    {
        Vendor.ORM orm = new Vendor.ORM();
        Vendor.Helpers h = new Vendor.Helpers();
        Controlles.LotesController lc = new Controlles.LotesController();
        public RegistroLotes()
        {
            InitializeComponent();
        }

        private void RegistroLotes_Load(object sender, EventArgs e)
        {
            this.Text = Env.APPNAME + "REGISTRAR LOTE | " + Vendor.Auth.USERNAME + " | " + Vendor.Auth.ROLE;
            TxtCodigo.Enabled = false;
            TxtDescripcion.Enabled = false;
        }

        private void RegistroLotes_Activated(object sender, EventArgs e)
        {
            TxtCodigo.Text = Program.CodProducto;
            TxtDescripcion.Text = Program.Producto;
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            lc.InsertCategoria(TxtCodigo.Text, TxtPrecio.Text, TxtCantidad.Text);
            TxtPrecio.Clear();
            TxtCantidad.Clear();
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
