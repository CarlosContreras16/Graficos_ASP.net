﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Views.Usuarios
{
    public partial class LoginView : Form
    {
        Controlles.UsuarioController uc = new Controlles.UsuarioController();
        public LoginView()
        {
            InitializeComponent();
        }

        private void LoginView_Load(object sender, EventArgs e)
        {
            this.Text = Env.APPNAME + "INICIAR SESION";
            Bootstrapper();
        }

        private void Bootstrapper()
        {
            if(Env.ENV == "DEV")
            {
                uc.RegisterSuperUser();
                uc.CreateUserTester();
            }    
        } 
        private void BtnLogin_Click(object sender, EventArgs e)
        {
           bool response = uc.Validate(TxtUSuario.Text, TxtClave.Text);
            if (response==true)
            {
                Views.Dashboard dash = new Dashboard();
                dash.Show();
                this.Hide();
            }
        }

        private void BtnViewPass_Click(object sender, EventArgs e)
        {
            TxtClave.UseSystemPasswordChar = TxtClave.UseSystemPasswordChar == false ? true : false;
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
