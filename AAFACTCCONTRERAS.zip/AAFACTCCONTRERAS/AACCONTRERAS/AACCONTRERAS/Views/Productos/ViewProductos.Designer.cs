﻿
namespace AACCONTRERAS.Views
{
    partial class ViewProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewProductos));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.TstOpciones = new System.Windows.Forms.ToolStrip();
            this.BtnNuevo = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnGuardar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnEditar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnEliminar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnCancelar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnSalir = new System.Windows.Forms.ToolStripButton();
            this.label1 = new System.Windows.Forms.Label();
            this.DgvProductos = new System.Windows.Forms.DataGridView();
            this.DcCodigo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DcProducto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DcPrecio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TxtDescripcion = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.TxtIncremento = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.TxtPrecioD = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.TxtPrecioM = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.TxtStockMin = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtCodigo = new System.Windows.Forms.TextBox();
            this.ChkGen = new System.Windows.Forms.CheckBox();
            this.CbCateogria = new System.Windows.Forms.ComboBox();
            this.CbMarca = new System.Windows.Forms.ComboBox();
            this.CbTipo = new System.Windows.Forms.ComboBox();
            this.CbFiscal = new System.Windows.Forms.ComboBox();
            this.CbIsv = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.CbInventario = new System.Windows.Forms.ComboBox();
            this.CbEntrada = new System.Windows.Forms.ComboBox();
            this.CbSalida = new System.Windows.Forms.ComboBox();
            this.BtnKardex = new System.Windows.Forms.Button();
            this.BtnLotes = new System.Windows.Forms.Button();
            this.BtnConfEsp = new System.Windows.Forms.Button();
            this.BtnPapelera = new System.Windows.Forms.Button();
            this.BtnRestaurar = new System.Windows.Forms.Button();
            this.BtnDestroy = new System.Windows.Forms.Button();
            this.TstOpciones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvProductos)).BeginInit();
            this.SuspendLayout();
            // 
            // TstOpciones
            // 
            this.TstOpciones.AutoSize = false;
            this.TstOpciones.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BtnNuevo,
            this.toolStripSeparator1,
            this.BtnGuardar,
            this.toolStripSeparator2,
            this.BtnEditar,
            this.toolStripSeparator3,
            this.BtnEliminar,
            this.toolStripSeparator4,
            this.BtnCancelar,
            this.toolStripSeparator5,
            this.BtnSalir});
            this.TstOpciones.Location = new System.Drawing.Point(0, 0);
            this.TstOpciones.Name = "TstOpciones";
            this.TstOpciones.Size = new System.Drawing.Size(902, 32);
            this.TstOpciones.TabIndex = 1;
            this.TstOpciones.Text = "toolStrip1";
            // 
            // BtnNuevo
            // 
            this.BtnNuevo.AutoSize = false;
            this.BtnNuevo.Image = ((System.Drawing.Image)(resources.GetObject("BtnNuevo.Image")));
            this.BtnNuevo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnNuevo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnNuevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnNuevo.Name = "BtnNuevo";
            this.BtnNuevo.Size = new System.Drawing.Size(80, 29);
            this.BtnNuevo.Text = "Nuevo";
            this.BtnNuevo.Click += new System.EventHandler(this.BtnNuevo_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 32);
            // 
            // BtnGuardar
            // 
            this.BtnGuardar.AutoSize = false;
            this.BtnGuardar.Image = ((System.Drawing.Image)(resources.GetObject("BtnGuardar.Image")));
            this.BtnGuardar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnGuardar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnGuardar.Name = "BtnGuardar";
            this.BtnGuardar.Size = new System.Drawing.Size(80, 29);
            this.BtnGuardar.Text = "Guardar";
            this.BtnGuardar.Click += new System.EventHandler(this.BtnGuardar_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 32);
            // 
            // BtnEditar
            // 
            this.BtnEditar.AutoSize = false;
            this.BtnEditar.Image = ((System.Drawing.Image)(resources.GetObject("BtnEditar.Image")));
            this.BtnEditar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEditar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnEditar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnEditar.Name = "BtnEditar";
            this.BtnEditar.Size = new System.Drawing.Size(80, 29);
            this.BtnEditar.Text = "Editar";
            this.BtnEditar.Click += new System.EventHandler(this.BtnEditar_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 32);
            // 
            // BtnEliminar
            // 
            this.BtnEliminar.AutoSize = false;
            this.BtnEliminar.Image = ((System.Drawing.Image)(resources.GetObject("BtnEliminar.Image")));
            this.BtnEliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnEliminar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnEliminar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnEliminar.Name = "BtnEliminar";
            this.BtnEliminar.Size = new System.Drawing.Size(80, 29);
            this.BtnEliminar.Text = "Eliminar";
            this.BtnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 32);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.AutoSize = false;
            this.BtnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("BtnCancelar.Image")));
            this.BtnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCancelar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(80, 29);
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 32);
            // 
            // BtnSalir
            // 
            this.BtnSalir.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.BtnSalir.AutoSize = false;
            this.BtnSalir.Image = ((System.Drawing.Image)(resources.GetObject("BtnSalir.Image")));
            this.BtnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSalir.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnSalir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnSalir.Name = "BtnSalir";
            this.BtnSalir.Size = new System.Drawing.Size(80, 29);
            this.BtnSalir.Text = "Salir";
            this.BtnSalir.Click += new System.EventHandler(this.BtnSalir_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "Datos Generales de los Productos";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // DgvProductos
            // 
            this.DgvProductos.AllowUserToAddRows = false;
            this.DgvProductos.AllowUserToDeleteRows = false;
            this.DgvProductos.AllowUserToResizeColumns = false;
            this.DgvProductos.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.AliceBlue;
            this.DgvProductos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.DgvProductos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvProductos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvProductos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DcCodigo,
            this.DcProducto,
            this.DcPrecio});
            this.DgvProductos.Location = new System.Drawing.Point(449, 68);
            this.DgvProductos.Name = "DgvProductos";
            this.DgvProductos.ReadOnly = true;
            this.DgvProductos.RowHeadersWidth = 5;
            this.DgvProductos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvProductos.Size = new System.Drawing.Size(441, 316);
            this.DgvProductos.TabIndex = 31;
            this.DgvProductos.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvProductos_CellDoubleClick);
            // 
            // DcCodigo
            // 
            this.DcCodigo.HeaderText = "CODIGO";
            this.DcCodigo.Name = "DcCodigo";
            this.DcCodigo.ReadOnly = true;
            // 
            // DcProducto
            // 
            this.DcProducto.HeaderText = "PRODUCTO";
            this.DcProducto.Name = "DcProducto";
            this.DcProducto.ReadOnly = true;
            // 
            // DcPrecio
            // 
            this.DcPrecio.HeaderText = "PRECIO";
            this.DcPrecio.Name = "DcPrecio";
            this.DcPrecio.ReadOnly = true;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Teal;
            this.label13.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(446, 32);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(405, 23);
            this.label13.TabIndex = 28;
            this.label13.Text = "Datos Generales de los Productos";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label11.Location = new System.Drawing.Point(14, 203);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 20);
            this.label11.TabIndex = 40;
            this.label11.Text = "MARCA:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label4.Location = new System.Drawing.Point(14, 172);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 20);
            this.label4.TabIndex = 39;
            this.label4.Text = "CATEGORIA:";
            // 
            // TxtDescripcion
            // 
            this.TxtDescripcion.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDescripcion.Location = new System.Drawing.Point(133, 94);
            this.TxtDescripcion.MaxLength = 200;
            this.TxtDescripcion.Multiline = true;
            this.TxtDescripcion.Name = "TxtDescripcion";
            this.TxtDescripcion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxtDescripcion.Size = new System.Drawing.Size(289, 66);
            this.TxtDescripcion.TabIndex = 35;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label3.Location = new System.Drawing.Point(14, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 20);
            this.label3.TabIndex = 36;
            this.label3.Text = "PRODUCTO:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label5.Location = new System.Drawing.Point(14, 265);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 20);
            this.label5.TabIndex = 42;
            this.label5.Text = "TIPO:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label6.Location = new System.Drawing.Point(14, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 20);
            this.label6.TabIndex = 44;
            this.label6.Text = "FISCALIZACION:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label7.Location = new System.Drawing.Point(319, 233);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 20);
            this.label7.TabIndex = 46;
            this.label7.Text = "ISV:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label9.Location = new System.Drawing.Point(257, 359);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 20);
            this.label9.TabIndex = 50;
            this.label9.Text = "SALIDA:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label10.Location = new System.Drawing.Point(14, 359);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 20);
            this.label10.TabIndex = 52;
            this.label10.Text = "ENTRADA:";
            // 
            // TxtIncremento
            // 
            this.TxtIncremento.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtIncremento.Location = new System.Drawing.Point(133, 390);
            this.TxtIncremento.Name = "TxtIncremento";
            this.TxtIncremento.Size = new System.Drawing.Size(93, 25);
            this.TxtIncremento.TabIndex = 53;
            this.TxtIncremento.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtIncremento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtIncremento_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label12.Location = new System.Drawing.Point(14, 393);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(106, 20);
            this.label12.TabIndex = 54;
            this.label12.Text = "INCREMENTAR:";
            // 
            // TxtPrecioD
            // 
            this.TxtPrecioD.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPrecioD.Location = new System.Drawing.Point(133, 420);
            this.TxtPrecioD.Name = "TxtPrecioD";
            this.TxtPrecioD.Size = new System.Drawing.Size(93, 25);
            this.TxtPrecioD.TabIndex = 55;
            this.TxtPrecioD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtPrecioD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtPrecioD_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label15.Location = new System.Drawing.Point(14, 424);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(89, 20);
            this.label15.TabIndex = 56;
            this.label15.Text = "PRECIO DET:";
            // 
            // TxtPrecioM
            // 
            this.TxtPrecioM.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtPrecioM.Location = new System.Drawing.Point(333, 419);
            this.TxtPrecioM.Name = "TxtPrecioM";
            this.TxtPrecioM.Size = new System.Drawing.Size(89, 25);
            this.TxtPrecioM.TabIndex = 57;
            this.TxtPrecioM.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtPrecioM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtPrecioM_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label16.Location = new System.Drawing.Point(238, 422);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 20);
            this.label16.TabIndex = 58;
            this.label16.Text = "PRECIOMAY:";
            // 
            // TxtStockMin
            // 
            this.TxtStockMin.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtStockMin.Location = new System.Drawing.Point(133, 450);
            this.TxtStockMin.Name = "TxtStockMin";
            this.TxtStockMin.Size = new System.Drawing.Size(78, 25);
            this.TxtStockMin.TabIndex = 59;
            this.TxtStockMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtStockMin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtStockMin_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label17.Location = new System.Drawing.Point(14, 455);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(84, 20);
            this.label17.TabIndex = 60;
            this.label17.Text = "STOCK MIN:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label2.Location = new System.Drawing.Point(14, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 20);
            this.label2.TabIndex = 33;
            this.label2.Text = "CODIGO BARRAS:";
            // 
            // TxtCodigo
            // 
            this.TxtCodigo.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCodigo.Location = new System.Drawing.Point(133, 63);
            this.TxtCodigo.Name = "TxtCodigo";
            this.TxtCodigo.Size = new System.Drawing.Size(153, 25);
            this.TxtCodigo.TabIndex = 34;
            // 
            // ChkGen
            // 
            this.ChkGen.AutoSize = true;
            this.ChkGen.Location = new System.Drawing.Point(293, 68);
            this.ChkGen.Name = "ChkGen";
            this.ChkGen.Size = new System.Drawing.Size(87, 17);
            this.ChkGen.TabIndex = 67;
            this.ChkGen.Text = "Auto generar";
            this.ChkGen.UseVisualStyleBackColor = true;
            // 
            // CbCateogria
            // 
            this.CbCateogria.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbCateogria.FormattingEnabled = true;
            this.CbCateogria.Location = new System.Drawing.Point(133, 171);
            this.CbCateogria.Name = "CbCateogria";
            this.CbCateogria.Size = new System.Drawing.Size(289, 21);
            this.CbCateogria.TabIndex = 68;
            // 
            // CbMarca
            // 
            this.CbMarca.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbMarca.FormattingEnabled = true;
            this.CbMarca.Location = new System.Drawing.Point(133, 203);
            this.CbMarca.Name = "CbMarca";
            this.CbMarca.Size = new System.Drawing.Size(289, 21);
            this.CbMarca.TabIndex = 69;
            // 
            // CbTipo
            // 
            this.CbTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbTipo.FormattingEnabled = true;
            this.CbTipo.Items.AddRange(new object[] {
            "PRODUCTO FINAL",
            "PRODUCTO PROCESADO",
            "PRODUCTO COMPUESTO",
            "SERVICIO"});
            this.CbTipo.Location = new System.Drawing.Point(133, 265);
            this.CbTipo.Name = "CbTipo";
            this.CbTipo.Size = new System.Drawing.Size(289, 21);
            this.CbTipo.TabIndex = 70;
            // 
            // CbFiscal
            // 
            this.CbFiscal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbFiscal.FormattingEnabled = true;
            this.CbFiscal.Items.AddRange(new object[] {
            "EXONERADO",
            "EXENTO",
            "GRAVADO"});
            this.CbFiscal.Location = new System.Drawing.Point(133, 234);
            this.CbFiscal.Name = "CbFiscal";
            this.CbFiscal.Size = new System.Drawing.Size(170, 21);
            this.CbFiscal.TabIndex = 71;
            this.CbFiscal.SelectedValueChanged += new System.EventHandler(this.CbFiscal_SelectedValueChanged);
            // 
            // CbIsv
            // 
            this.CbIsv.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbIsv.FormattingEnabled = true;
            this.CbIsv.Items.AddRange(new object[] {
            "0",
            "0",
            "15"});
            this.CbIsv.Location = new System.Drawing.Point(364, 233);
            this.CbIsv.Name = "CbIsv";
            this.CbIsv.Size = new System.Drawing.Size(58, 21);
            this.CbIsv.TabIndex = 72;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.Teal;
            this.label21.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(1, 300);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(295, 23);
            this.label21.TabIndex = 74;
            this.label21.Text = "Especifique como se manejará el inventario";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(71)))), ((int)(((byte)(71)))));
            this.label22.Location = new System.Drawing.Point(14, 329);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(90, 20);
            this.label22.TabIndex = 75;
            this.label22.Text = "INVENTARIO:";
            // 
            // CbInventario
            // 
            this.CbInventario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbInventario.FormattingEnabled = true;
            this.CbInventario.Items.AddRange(new object[] {
            "SI",
            "NO"});
            this.CbInventario.Location = new System.Drawing.Point(133, 328);
            this.CbInventario.Name = "CbInventario";
            this.CbInventario.Size = new System.Drawing.Size(93, 21);
            this.CbInventario.TabIndex = 76;
            // 
            // CbEntrada
            // 
            this.CbEntrada.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbEntrada.FormattingEnabled = true;
            this.CbEntrada.Location = new System.Drawing.Point(133, 358);
            this.CbEntrada.Name = "CbEntrada";
            this.CbEntrada.Size = new System.Drawing.Size(118, 21);
            this.CbEntrada.TabIndex = 77;
            // 
            // CbSalida
            // 
            this.CbSalida.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbSalida.FormattingEnabled = true;
            this.CbSalida.Location = new System.Drawing.Point(323, 358);
            this.CbSalida.Name = "CbSalida";
            this.CbSalida.Size = new System.Drawing.Size(99, 21);
            this.CbSalida.TabIndex = 78;
            // 
            // BtnKardex
            // 
            this.BtnKardex.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKardex.Image = ((System.Drawing.Image)(resources.GetObject("BtnKardex.Image")));
            this.BtnKardex.Location = new System.Drawing.Point(460, 396);
            this.BtnKardex.Name = "BtnKardex";
            this.BtnKardex.Size = new System.Drawing.Size(84, 36);
            this.BtnKardex.TabIndex = 79;
            this.BtnKardex.Text = "Kardex";
            this.BtnKardex.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnKardex.UseVisualStyleBackColor = true;
            // 
            // BtnLotes
            // 
            this.BtnLotes.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLotes.Image = ((System.Drawing.Image)(resources.GetObject("BtnLotes.Image")));
            this.BtnLotes.Location = new System.Drawing.Point(566, 396);
            this.BtnLotes.Name = "BtnLotes";
            this.BtnLotes.Size = new System.Drawing.Size(83, 36);
            this.BtnLotes.TabIndex = 80;
            this.BtnLotes.Text = "Lotes";
            this.BtnLotes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnLotes.UseVisualStyleBackColor = true;
            this.BtnLotes.Click += new System.EventHandler(this.BtnLotes_Click);
            // 
            // BtnConfEsp
            // 
            this.BtnConfEsp.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnConfEsp.Image = ((System.Drawing.Image)(resources.GetObject("BtnConfEsp.Image")));
            this.BtnConfEsp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnConfEsp.Location = new System.Drawing.Point(675, 396);
            this.BtnConfEsp.Name = "BtnConfEsp";
            this.BtnConfEsp.Size = new System.Drawing.Size(105, 36);
            this.BtnConfEsp.TabIndex = 81;
            this.BtnConfEsp.Text = "Conf. Especial";
            this.BtnConfEsp.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnConfEsp.UseVisualStyleBackColor = true;
            // 
            // BtnPapelera
            // 
            this.BtnPapelera.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPapelera.Image = ((System.Drawing.Image)(resources.GetObject("BtnPapelera.Image")));
            this.BtnPapelera.Location = new System.Drawing.Point(806, 396);
            this.BtnPapelera.Name = "BtnPapelera";
            this.BtnPapelera.Size = new System.Drawing.Size(80, 36);
            this.BtnPapelera.TabIndex = 82;
            this.BtnPapelera.Text = "Papelera";
            this.BtnPapelera.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnPapelera.UseVisualStyleBackColor = true;
            this.BtnPapelera.Click += new System.EventHandler(this.BtnPapelera_Click);
            // 
            // BtnRestaurar
            // 
            this.BtnRestaurar.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRestaurar.Image = ((System.Drawing.Image)(resources.GetObject("BtnRestaurar.Image")));
            this.BtnRestaurar.Location = new System.Drawing.Point(806, 438);
            this.BtnRestaurar.Name = "BtnRestaurar";
            this.BtnRestaurar.Size = new System.Drawing.Size(80, 36);
            this.BtnRestaurar.TabIndex = 83;
            this.BtnRestaurar.Text = "Restaurar";
            this.BtnRestaurar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnRestaurar.UseVisualStyleBackColor = true;
            this.BtnRestaurar.Visible = false;
            this.BtnRestaurar.Click += new System.EventHandler(this.BtnRestaurar_Click);
            // 
            // BtnDestroy
            // 
            this.BtnDestroy.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDestroy.Image = ((System.Drawing.Image)(resources.GetObject("BtnDestroy.Image")));
            this.BtnDestroy.Location = new System.Drawing.Point(720, 439);
            this.BtnDestroy.Name = "BtnDestroy";
            this.BtnDestroy.Size = new System.Drawing.Size(80, 36);
            this.BtnDestroy.TabIndex = 84;
            this.BtnDestroy.Text = "Eliminar";
            this.BtnDestroy.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnDestroy.UseVisualStyleBackColor = true;
            this.BtnDestroy.Visible = false;
            // 
            // ViewProductos
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(902, 489);
            this.ControlBox = false;
            this.Controls.Add(this.BtnDestroy);
            this.Controls.Add(this.BtnRestaurar);
            this.Controls.Add(this.BtnPapelera);
            this.Controls.Add(this.BtnConfEsp);
            this.Controls.Add(this.BtnLotes);
            this.Controls.Add(this.BtnKardex);
            this.Controls.Add(this.CbSalida);
            this.Controls.Add(this.CbEntrada);
            this.Controls.Add(this.CbInventario);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.CbIsv);
            this.Controls.Add(this.CbFiscal);
            this.Controls.Add(this.CbTipo);
            this.Controls.Add(this.CbMarca);
            this.Controls.Add(this.CbCateogria);
            this.Controls.Add(this.ChkGen);
            this.Controls.Add(this.TxtStockMin);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.TxtPrecioM);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.TxtPrecioD);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.TxtIncremento);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TxtDescripcion);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TxtCodigo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DgvProductos);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TstOpciones);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "ViewProductos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "---";
            this.Load += new System.EventHandler(this.Productos_Load);
            this.TstOpciones.ResumeLayout(false);
            this.TstOpciones.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvProductos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip TstOpciones;
        private System.Windows.Forms.ToolStripButton BtnNuevo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton BtnGuardar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton BtnEditar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton BtnEliminar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton BtnCancelar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton BtnSalir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView DgvProductos;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TxtDescripcion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox TxtIncremento;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TxtPrecioD;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox TxtPrecioM;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox TxtStockMin;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtCodigo;
        private System.Windows.Forms.CheckBox ChkGen;
        private System.Windows.Forms.ComboBox CbCateogria;
        private System.Windows.Forms.ComboBox CbMarca;
        private System.Windows.Forms.ComboBox CbTipo;
        private System.Windows.Forms.ComboBox CbFiscal;
        private System.Windows.Forms.ComboBox CbIsv;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox CbInventario;
        private System.Windows.Forms.ComboBox CbEntrada;
        private System.Windows.Forms.ComboBox CbSalida;
        private System.Windows.Forms.DataGridViewTextBoxColumn DcCodigo;
        private System.Windows.Forms.DataGridViewTextBoxColumn DcProducto;
        private System.Windows.Forms.DataGridViewTextBoxColumn DcPrecio;
        private System.Windows.Forms.Button BtnKardex;
        private System.Windows.Forms.Button BtnLotes;
        private System.Windows.Forms.Button BtnConfEsp;
        private System.Windows.Forms.Button BtnPapelera;
        private System.Windows.Forms.Button BtnRestaurar;
        private System.Windows.Forms.Button BtnDestroy;
    }
}