﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace AACCONTRERAS.Models
{
    class RegistrarCaisModel
    {
        Vendor.ORM orm = new Vendor.ORM();
        Vendor.Helpers h = new Vendor.Helpers();

        public bool InsertCais(string refcai, string cai, DateTime fechalim, string prefijo, string facturaini, string facturafin, DateTime fecharec, string usuario)
        {
            bool response = false;

            string condition = "REFCAI, CAI, FECHALIM, PREFIJO, FACTURAINI, FACTURAFIN, FECHAREC, USUARIO";
            string values = "'" + refcai + "', '" + cai + "', '" + fechalim + "', '" + prefijo + "', '" + facturaini + "', '" + facturafin + "', '" + fecharec + "', '" + usuario + "'";

            try
            {
                if (orm.Save("CAIS", condition, values) > 0)
                {
                    h.MsgSuccess("EL CAI HA SIDO INGRESADO CORRECTAMENTE");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }

            return response;
        }

        public bool UpdateCais(string refcai, string cai, DateTime fechalim, string prefijo, string facturaini, string facturafin, DateTime fecharec, string usuario)
        {
            bool response = false;

            string data = "CAI='" + cai  + "', FECHALIM='" + fechalim + "', PREFIJO='" + prefijo + "',FACTURAINI='" + facturaini + "',FACTURAFIN='" + facturafin + "',FECHAREC='" + fecharec + "',USUARIO='" + usuario + "'";
            string condition = "REFCAI='" + refcai + "'";

            try
            {
                if (orm.Update("CAIS", data, condition) > 0)
                {
                    h.MsgSuccess("CAI ACTUALIZADA CORRECTAMENTE");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }

            return response;
        }

        public bool DeleteCategoria(string value)
        {
            bool response = false;
            string condition = "REFCAI";
            string values = value;


            try
            {
                if (orm.Delete("CAIS", condition, values) > 0)
                {
                    h.MsgSuccess("CAI ELIMINADA CORRECTAMENTE");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }

            return response;
        }

        public bool ShowCais(DataGridView dgv)
        {
            string refcai, cai, factini, factfin, estado;
            bool response = false;
            DataTable registros;
            registros = new DataTable();
            registros = orm.Find("CAIS", "REFCAI, CAI, FACTURAINI, FACTURAFIN, ESTADO", "DEL<>'S'","REFCAI DESC");
            if (registros.Rows.Count > 0)
            {
                dgv.Rows.Clear();
                int i;
                for (i = 0; i < registros.Rows.Count; i++)
                {
                    refcai  = registros.Rows[i][0].ToString();
                    cai = registros.Rows[i][1].ToString();
                    factini = registros.Rows[i][2].ToString();
                    factfin = registros.Rows[i][3].ToString();
                    estado = registros.Rows[i][4].ToString();
                    dgv.Rows.Add(refcai, cai, factini, factfin, estado);

                    if (estado=="ACTIVO")
                    {
                        dgv.Rows[i].DefaultCellStyle.ForeColor = System.Drawing.Color.Green;
                    }
                    else
                    {
                        dgv.Rows[i].DefaultCellStyle.ForeColor = System.Drawing.Color.Red;
                    }
                }
            }
            return response;
        }
        public bool BuscarCai(DataGridView dgv, string buscar)
        {
            bool response = false;

            string id, cat, del, fecha;
            DataTable registros;
            registros = new DataTable();
            string columns, condition;
            columns = "IDCATE, CATEGORIA, DEL, REGISTRO";
            condition = "IDCATE LIKE '%" + buscar + "%' OR CATEGORIA LIKE '%" + buscar + "%'";
            registros = orm.Find("CATEGORIASPRODUCTOS", columns, condition);
            if (registros.Rows.Count > 0)
            {
                dgv.Rows.Clear();
                int i;
                for (i = 0; i < registros.Rows.Count; i++)
                {
                    id = registros.Rows[i][0].ToString();
                    cat = registros.Rows[i][1].ToString();
                    del = registros.Rows[i][2].ToString();
                    fecha = registros.Rows[i][3].ToString();
                    dgv.Rows.Add(id, cat, del, fecha);
                }
            }
            return response;
        }
        public string NewIdCate(string idcorre)
        {
            string id = "";

            id = orm.GetNext(idcorre);

            return id;
        }

        public void UpdateIdCate(string idcorre)
        {
            orm.SetLast(idcorre);
        }
    }
}
