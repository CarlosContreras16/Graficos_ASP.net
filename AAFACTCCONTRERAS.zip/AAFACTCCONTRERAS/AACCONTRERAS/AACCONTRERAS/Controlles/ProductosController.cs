﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Controlles
{
    class ProductosController
    {
        Vendor.Helpers h = new Vendor.Helpers();
        Vendor.ORM orm = new Vendor.ORM();
        Models.ProductosModel pm = new Models.ProductosModel();

        public bool InsertProducto(string codbarras, string descripcion, string idcate, string idmarca, 
            string fiscal, string isv, string tipoprod, string min, string idpresin, string idpresout, 
            string increment, string preciodet, string preciomay, string stockmin)
        {
            bool response = true;
            string cod = h.Clean(codbarras.Trim());
            string des = h.Clean(descripcion.Trim());
            string cat = h.Clean(idcate.Trim());
            string mar = h.Clean(idmarca.Trim());
            string fisc = h.Clean(fiscal.Trim());
            string imp = h.Clean(isv.Trim());
            string tipopr = h.Clean(tipoprod.Trim());
            string minim = h.Clean(min.Trim());
            string presin = h.Clean(idpresin.Trim());
            string presout = h.Clean(idpresout.Trim());
            string incr = increment.Trim();
            string precdet = preciodet.Trim();
            string precmay = preciomay.Trim();
            string stock = stockmin.Trim();

            string errors = "";

            if (cod.Length==0)
            {
                errors += "INGRESAR CODIGO\n";
                response = false;
            }
            if (des.Length == 0)
            {
                errors += "INGRESAR DESCRIPCION\n";
                response = false;
            }
            if (cat.Length == 0)
            {
                errors += "INGRESAR CATEGORIA\n";
                response = false;
            }
            if (mar.Length == 0)
            {
                errors += "INGRESAR MARCA\n";
                response = false;
            }
            if (fisc.Length == 0)
            {
                errors += "INGRESAR FISCALIZACION\n";
                response = false;
            }
            if (imp.Length == 0)
            {
                errors += "INGRESAR IMPUESTO\n";
                response = false;
            }
            if (tipopr.Length == 0)
            {
                errors += "INGRESAR TIPO\n";
                response = false;
            }
            if (minim.Length == 0)
            {
                errors += "INGRESAR INVENTARIO\n";
                response = false;
            }
            if (presin.Length == 0)
            {
                errors += "INGRESAR PRECIO\n";
                response = false;
            }
            if (presout.Length == 0)
            {
                errors += "INGRESAR PRECIO SALIDA\n";
                response = false;
            }
            if (incr.Length == 0)
            {
                errors += "INGRESAR INCREMENTO\n";
                response = false;
            }
            if (precdet.Length == 0)
            {
                errors += "INGRESAR PRECIO\n";
                response = false;
            }
            if (precmay.Length == 0)
            {
                errors += "INGRESAR PRECIO MAYOR\n";
                response = false;
            }
            if (stock.Length == 0)
            {
                errors += "INGRESAR STOCK MINIMO\n";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = pm.InsertProducto(cod,des, cat, mar, fisc,imp, tipopr,minim, presin,presout, incr, precdet, precmay,stock);
            }
            return response;
        }

        public bool UpdateProducto(string codbarras, string descripcion, string idcate, string idmarca, string fiscal, string isv, string tipoprod, string min, string idpresin, string idpresout, string increment, string preciodet, string preciomay, string stockmin)
        {
            bool response = true;
            string cod = h.Clean(codbarras.Trim());
            string des = h.Clean(descripcion.Trim());
            string cat = h.Clean(idcate.Trim());
            string mar = h.Clean(idmarca.Trim());
            string fisc = h.Clean(fiscal.Trim());
            string imp = h.Clean(isv.Trim());
            string tipopr = h.Clean(tipoprod.Trim());
            string minim = h.Clean(min.Trim());
            string presin = h.Clean(idpresin.Trim());
            string presout = h.Clean(idpresout.Trim());
            string incr = increment.Trim();
            string precdet = preciodet.Trim();
            string precmay = preciomay.Trim();
            string stock = stockmin.Trim();

            string errors = "";

            if (cod.Length == 0)
            {
                errors += "INGRESAR CODIGO\n";
                response = false;
            }
            if (des.Length == 0)
            {
                errors += "INGRESAR DESCRIPCION\n";
                response = false;
            }
            if (cat.Length == 0)
            {
                errors += "INGRESAR CATEGORIA\n";
                response = false;
            }
            if (mar.Length == 0)
            {
                errors += "INGRESAR MARCA\n";
                response = false;
            }
            if (fisc.Length == 0)
            {
                errors += "INGRESAR FISCALIZACION\n";
                response = false;
            }
            if (imp.Length == 0)
            {
                errors += "INGRESAR IMPUESTO\n";
                response = false;
            }
            if (tipopr.Length == 0)
            {
                errors += "INGRESAR TIPO\n";
                response = false;
            }
            if (minim.Length == 0)
            {
                errors += "INGRESAR INVENTARIO\n";
                response = false;
            }
            if (presin.Length == 0)
            {
                errors += "INGRESAR PRECIO\n";
                response = false;
            }
            if (presout.Length == 0)
            {
                errors += "INGRESAR PRECIO SALIDA\n";
                response = false;
            }
            if (incr.Length == 0)
            {
                errors += "INGRESAR INCREMENTO\n";
                response = false;
            }
            if (precdet.Length == 0)
            {
                errors += "INGRESAR PRECIO\n";
                response = false;
            }
            if (precmay.Length == 0)
            {
                errors += "INGRESAR PRECIO MAYOR\n";
                response = false;
            }
            if (stock.Length == 0)
            {
                errors += "INGRESAR STOCK MINIMO\n";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = pm.UpdateProducto(cod, des, cat, mar, fisc, imp, tipopr, minim, presin, presout, incr, precdet, precmay, stock);
            }
            return response;
        }

        public bool DeleteProducto(string codbarra)
        {
            bool response = true;
            string val = h.Clean(codbarra.Trim());
            string errors = "";
            if (val.Length == 0)
            {
                errors += "INGRESAR CODIGO DE BARRAS";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = pm.DeleteProducto(val);
            }
            return response;
        }
        public bool ShowProducto(DataGridView dgv)

        {
            bool response = true;

            if (response == false)
            {
                h.Warning("Error");
            }
            else
            {
                response = pm.ShowProducto(dgv);
            }
            return response;
        }
        public bool BuscarProducto(DataGridView dgv, string buscar)
        {
            bool response = true;
            if (response == false)
            {
                h.Warning("Error");
            }
            else
            {
                response = pm.BuscarProducto(dgv, buscar);
            }
            return response;
        }
        public void UpdateCodBarra(string codbarra, string descr, string cat, string marca, string fisc, string tipo, string inv, string entra, string salida, string incr, string pre, string preciom, string stock)
        {
            if (codbarra.Length == 0 || descr.Length == 0 || cat.Length == 0 || marca.Length == 0 || fisc.Length == 0 || tipo.Length == 0 || inv.Length == 0 || entra.Length == 0 || salida.Length == 0 || incr.Length == 0 || pre.Length == 0 || pre.Length == 0 || preciom.Length == 0 || stock.Length == 0)
            {
                return;
            }
            else
            {
                pm.UpdateCodBarra(codbarra);
            }

        }
    }
}
