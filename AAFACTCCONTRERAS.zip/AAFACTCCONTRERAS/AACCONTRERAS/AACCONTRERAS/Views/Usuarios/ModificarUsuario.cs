﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Views.Usuarios
{
    public partial class ModificarUsuario : Form
    {
        Vendor.ORM orm = new Vendor.ORM();
        Vendor.Helpers h = new Vendor.Helpers();
        Controlles.UsuarioController uc = new Controlles.UsuarioController();
        public ModificarUsuario()
        {
            InitializeComponent();
        }

        private void ModificarUsuario_Load(object sender, EventArgs e)
        {
            this.Text = "CAMBIO DE DATOS DEL USUARIO | @" + Vendor.Auth.USERNAME;
            TxtUsuario.Text = Vendor.Auth.USERNAME;
            uc.GetInfoCliente(Vendor.Auth.USERNAME);

            TxtNombre.Text = Program.Nombre;
            CbSexo.Text = Program.Sexo;
            DtFecha.Value =Convert.ToDateTime(Program.Fechanac);
            TxtCorreo.Text = Program.Correo;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnGuardarPass_Click(object sender, EventArgs e)
        {
            uc.VerificarPass(TxtClave.Text, TxtNuevaClave.Text, TxtConfirmar.Text);
        }

        private void BtnGuardarDatos_Click(object sender, EventArgs e)
        {
            uc.ModificarUsuario(TxtNombre.Text, CbSexo.Text, DtFecha.Value, TxtCorreo.Text);
        }
    }
}
