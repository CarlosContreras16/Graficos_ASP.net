﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Controlles
{
    class ClientesController
    {
        Vendor.Helpers h = new Vendor.Helpers();
        Vendor.ORM orm = new Vendor.ORM();
        Models.ClientesModels cm = new Models.ClientesModels();

        public bool InsertCliente(string idcliente, string rtn, string cliente, string direccion, string telefono, string telfonomovil, DateTime fechanac, string tipo, string correo)
        {
            string errors = "";
            string id = h.Clean(idcliente.Trim());
            string rt = h.Clean(rtn.Trim());
            string clie = h.Clean(cliente.Trim());
            string direc = h.Clean(direccion.Trim());
            string tel = h.Clean(telefono.Trim());
            string telm = h.Clean(telfonomovil.Trim());
            string tip = h.Clean(tipo.Trim());
            string corr = h.Clean(correo.Trim());
            bool response = true;

            if (id.Length==0)
            {
                errors = "INGRESAR CODIGO\n";
                response = false;
            }
            if (rt.Length == 0)
            {
                errors = "INGRESAR RTN\n";
                response = false;
            }
            if (clie.Length == 0)
            {
                errors = "INGRESAR NOMBRE\n";
                response = false;
            }
            if (direc.Length == 0)
            {
                errors = "INGRESAR DIRECCION\n";
                response = false;
            }
            if (tel.Length == 0)
            {
                errors = "INGRESAR TELEFONO\n";
                response = false;
            }
            if (telm.Length == 0)
            {
                errors = "INGRESAR TELFONO MOVIL\n";
                response = false;
            }
            if (tip.Length == 0)
            {
                errors = "INGRESAR TIPO\n";
                response = false;
            }
            if (corr.Length == 0)
            {
                errors = "INGRESAR CORREO\n";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = cm.InsertCliente(id, rt, clie,direc,tel,telm,fechanac,tip,corr);
            }
            return response;
        }
        public bool EditarCliente(string idcliente, string rtn, string cliente, string direccion, string telefono, string telfonomovil, DateTime fechanac, string tipo, string correo)
        {
            string errors = "";
            string id = h.Clean(idcliente.Trim());
            string rt = h.Clean(rtn.Trim());
            string clie = h.Clean(cliente.Trim());
            string direc = h.Clean(direccion.Trim());
            string tel = h.Clean(telefono.Trim());
            string telm = h.Clean(telfonomovil.Trim());
            string tip = h.Clean(tipo.Trim());
            string corr = h.Clean(correo.Trim());
            bool response = true;

            if (id.Length == 0)
            {
                errors = "INGRESAR CODIGO\n";
                response = false;
            }
            if (rt.Length == 0)
            {
                errors = "INGRESAR RTN\n";
                response = false;
            }
            if (clie.Length == 0)
            {
                errors = "INGRESAR NOMBRE\n";
                response = false;
            }
            if (direc.Length == 0)
            {
                errors = "INGRESAR DIRECCION\n";
                response = false;
            }
            if (tel.Length == 0)
            {
                errors = "INGRESAR TELEFONO\n";
                response = false;
            }
            if (telm.Length == 0)
            {
                errors = "INGRESAR TELFONO MOVIL\n";
                response = false;
            }
            if (tip.Length == 0)
            {
                errors = "INGRESAR TIPO\n";
                response = false;
            }
            if (corr.Length == 0)
            {
                errors = "INGRESAR CORREO\n";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = cm.UpdateCliente(id, rt, clie, direc, tel, telm, fechanac, tip, corr);
            }
            return response;
        }
        public bool EliminarCliente(string value)
        {
            bool response = true;
            string val = h.Clean(value.Trim());
            string errors = "";
            if (val.Length == 0)
            {
                errors += "INGRESAR CODIGO DEL CLIENTE";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = cm.DeleteCliente(val);
            }
            return response;
        }
        public bool MostrarCientes(DataGridView dgv)
        {
            bool response = true;

            if (response == false)
            {
                h.Warning("Error");
            }
            else
            {
                response = cm.ShowCliente(dgv);
            }
            return response;
        }
        public bool BuscarCliente(DataGridView dgv, string buscar)
        {
            bool response = true;
            if (response == false)
            {
                h.Warning("Error");
            }
            else
            {
                response = cm.BuscarCliente(dgv, buscar);
            }
            return response;
        }
        public string NewIdCliente(string idcorre)
        {
            string id = "";
            id = cm.NewIdCliente(idcorre);

            return id;
        }


        public void UpdateCodCliente(string idcliente, string rtn, string cliente, string direccion, string telefono, string telfonomovil, string tipo, string correo)
        {
            if (idcliente.Length == 0 || rtn.Length == 0 || cliente.Length == 0 || direccion.Length == 0 || telefono.Length == 0 || tipo.Length == 0 || telfonomovil.Length == 0 || tipo.Length == 0 || correo.Length == 0)
            {
                return;
            }
            else
            {
                cm.UpdateIdCliente(idcliente);
            }

        }
    }
}
