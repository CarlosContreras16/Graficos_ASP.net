﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace AACCONTRERAS.Models
{
    class MarcasProdModel
    {
        Vendor.ORM orm = new Vendor.ORM();
        Vendor.Helpers h = new Vendor.Helpers();

        public bool InsertMarcas(string idcate, string categoria)
        {
            bool response = false;

            string condition = "IDMARCA, MARCA";
            string values = "'" + idcate + "', '" + categoria + "'";

            try
            {
                if (orm.Save("MARCASPRODUCTOS", condition, values) > 0)
                {
                    h.MsgSuccess("La categoria ha sido ingresado correctamente");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }

            return response;
        }

        public bool UpdateMarca(string idcate, string categoria)
        {
            bool response = false;

            string data = "MARCA='" + categoria + "'";
            string condition = "IDMARCA='" + idcate + "'";

            try
            {
                if (orm.Update("MARCASPRODUCTOS", data, condition) > 0)
                {
                    h.MsgSuccess("CATEGORIA ACTUALIZADA CORRECTAMENTE");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }

            return response;
        }

        public bool DeleteMarcas(string value)
        {
            bool response = false;
            string condition = "IDMARCA";
            string values = value;


            try
            {
                if (orm.Delete("MARCASPRODUCTOS", condition, values) > 0)
                {
                    h.MsgSuccess("MARCA ELIMINADA CORRECTAMENTE");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }

            return response;
        }

        public bool ShowMarcas(DataGridView dgv)
        {
            string id, mar, del, fecha;
            bool response = false;
            DataTable registros;
            registros = new DataTable();
            registros = orm.Find("MARCASPRODUCTOS", "*", "DEL<>'S'");
            if (registros.Rows.Count > 0)
            {
                dgv.Rows.Clear();
                int i;
                for (i = 0; i < registros.Rows.Count; i++)
                {
                    id = registros.Rows[i][0].ToString();
                    mar = registros.Rows[i][1].ToString();
                    del = registros.Rows[i][2].ToString();
                    fecha = registros.Rows[i][3].ToString();
                    dgv.Rows.Add(id, mar, del, fecha);
                }
            }
            return response;
        }

        public bool BuscarMarca(DataGridView dgv, string buscar)
        {
            bool response = false;

            string id, cat, del, fecha;
            DataTable registros;
            registros = new DataTable();
            string columns, condition;
            columns = "IDMARCA, MARCA, DEL, REGISTRO";
            condition = "IDMARCA LIKE '%" + buscar + "%' OR MARCA LIKE '%" + buscar + "%'";
            registros = orm.Find("MARCASPRODUCTOS", columns, condition);
            if (registros.Rows.Count > 0)
            {
                dgv.Rows.Clear();
                int i;
                for (i = 0; i < registros.Rows.Count; i++)
                {
                    id = registros.Rows[i][0].ToString();
                    cat = registros.Rows[i][1].ToString();
                    del = registros.Rows[i][2].ToString();
                    fecha = registros.Rows[i][3].ToString();
                    dgv.Rows.Add(id, cat, del, fecha);
                }
            }
            return response;
        }

        public string NewIdMarca(string idcorre)
        {
            string id = "";

            id = orm.GetNext(idcorre);

            return id;
        }

        public void UpdateIdMarca(string idcorre)
        {
            orm.SetLast(idcorre);
        }
    }
}
