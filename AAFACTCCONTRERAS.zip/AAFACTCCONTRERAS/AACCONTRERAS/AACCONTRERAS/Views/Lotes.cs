﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Views
{
    public partial class Lotes : Form
    {
        Controlles.LotesController lc = new Controlles.LotesController();
        public Lotes()
        {
            InitializeComponent();
        }

        private void Lotes_Load(object sender, EventArgs e)
        {
            this.Text = Env.APPNAME + "ARCHIVOS DE LOTES | " + Vendor.Auth.USERNAME + " | " + Vendor.Auth.ROLE;
            TxtCodigo.Enabled = false;
            TxtDescripcion.Enabled = false;
        }

        private void BtnRegistrar_Click(object sender, EventArgs e)
        {
            RegistroLotes registro = new RegistroLotes();
            this.AddOwnedForm(registro);
            registro.ShowDialog();
        }

        private void TxtCodigo_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void Lotes_Activated(object sender, EventArgs e)
        {
            TxtCodigo.Text = Program.CodProducto;
            TxtDescripcion.Text = Program.Producto;
            lc.MostrarLotes(TxtCodigo.Text, DgvLotes);
            TxtStock.Enabled = false;
            SumarCantidad();
        }
        private void SumarCantidad()
        {
            int suma = 0;
            foreach (DataGridViewRow row in DgvLotes.Rows)
            {
                suma += Convert.ToInt32(row.Cells[3].Value);
            }
            TxtStock.Text = suma.ToString();
        }
    }
}
