﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;

namespace AACCONTRERAS.Models
{
    internal class ClientesModels
    {
        Vendor.ORM orm = new Vendor.ORM();
        Vendor.Helpers h = new Vendor.Helpers();

        public bool InsertCliente(string idcliente, string rtn, string cliente, string direccion, string telefono, string telfonomovil, DateTime fechanac, string tipo, string correo)
        {
            bool response = false;
            string condition = "IDCLIENTE, RTN, CLIENTE, DIRECCION, TELEFONO, TELMOVIL, FECHANAC, TIPO, CORREO";
            string values = "'" + idcliente + "','" + rtn + "', '" + cliente + "','" + direccion + "', '" + telefono + "', '" + telfonomovil + "', '" + fechanac + "', '" + tipo + "', '" + correo + "'";

            try
            {
                if (orm.Save("CLIENTES", condition, values) > 0)
                {
                    h.MsgSuccess("El cliente ha sido ingresado correctamente");
                    response = true;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return response;
        }

        public bool UpdateCliente(string idcliente, string rtn, string cliente, string direccion, string telefono, string telfonomovil, DateTime fechanac, string tipo, string correo)
        {
            bool response = false;

            string data = "RTN = '" + rtn + "', CLIENTE='" + cliente + "', DIRECCION='" + direccion + "', TELEFONO='" + telefono + "', TELMOVIL='" + telfonomovil + "', FECHANAC='" + fechanac + "', TIPO='" + tipo + "', CORREO='" + correo + "'";
            string condition = "IDCLIENTE = '" + idcliente + "'";

            if (orm.Update("CLIENTES", data, condition) > 0)
            {
                h.MsgSuccess("CLIENTE ACTUALIZADO CORRECTAMENTE");
                response = true;
            }
            else
            {
                h.Warning("ERROR AL ACTUALIZAR");
            }
            return response;
        }

        public bool DeleteCliente(string idcliente)
        {
            bool response = false;
            string condition = "IDCLIENTE";
            string values = idcliente;

             if (orm.Delete("CLIENTES", condition, values) > 0)
             {
                 h.MsgSuccess("CLIENTE ELIMINADO CORRECTAMENTE");
                 response = true;
             }
            

            return response;
        }

        public bool ShowCliente(DataGridView dgv)
        {
            string codigo, rtn, cliente;
            bool response = false;
            DataTable Registros = new DataTable();
            Registros = orm.Find("CLIENTES", "IDCLIENTE, RTN, CLIENTE", "DEL<>'S'");
            if (Registros.Rows.Count > 0 )
            {
                dgv.Rows.Clear();
                int i;
                for (i = 0; i < Registros.Rows.Count; i++)
                {
                    codigo = Registros.Rows[i][0].ToString();
                    rtn = Registros.Rows[i][1].ToString();
                    cliente = Registros.Rows[i][2].ToString();
                    dgv.Rows.Add(codigo, rtn, cliente);
                }
            }
            else
            {
                h.Warning("Error");
            }
            return response;
        }
        public bool BuscarCliente(DataGridView dgv, string buscar)
        {
            bool response = false;

            string codigo, rtn, cliente;
            DataTable Registros;
            Registros = new DataTable();
            string columns, condition;
            columns = "IDCLIENTE, RTN, CLIENTE";
            condition = "IDCLIENTE LIKE '%" + buscar + "%' OR CLIENTE LIKE '%" + buscar + "%' OR RTN LIKE '%" + buscar + "%'";
            Registros = orm.Find("CATEGORIASPRODUCTOS", columns, condition);
            if (Registros.Rows.Count > 0)
            {
                dgv.Rows.Clear();
                int i;
                for (i = 0; i < Registros.Rows.Count; i++)
                {
                    codigo = Registros.Rows[i][0].ToString();
                    rtn = Registros.Rows[i][1].ToString();
                    cliente = Registros.Rows[i][2].ToString();
                    dgv.Rows.Add(codigo, rtn, cliente);
                }
            }
            return response;
        }
        public string NewIdCliente(string idcorre)
        {
            string id = "";

            id = orm.GetNext(idcorre);

            return id;
        }

        public void UpdateIdCliente(string idcorre)
        {
            orm.SetLast(idcorre);
        }
    }
}
