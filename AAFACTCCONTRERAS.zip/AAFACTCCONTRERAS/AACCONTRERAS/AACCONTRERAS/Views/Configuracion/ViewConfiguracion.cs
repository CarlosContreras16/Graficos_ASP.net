﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Views.Configuracion
{
    public partial class ViewConfiguracion : Form
    {
        Vendor.ORM orm = new Vendor.ORM();
        Vendor.Helpers h = new Vendor.Helpers();
        Controlles.ConfiguracionController confi = new Controlles.ConfiguracionController();
        public ViewConfiguracion()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = h.GetOnlyNumbers(e) ? false : true;
        }

        private void ViewConfiguracion_Load(object sender, EventArgs e)
        {

            this.Text = Env.APPNAME + " CONFIGURACION";
            confi.MostrarConfiguracion(DgvConfiguracion);
            BtnEditar.Enabled = false;
            BtnEliminar.Enabled = false;
            if (DgvConfiguracion.Rows.Count > 0)
            {
                BtnGuardar.Enabled = false;
                BtnGestionar.Visible = true;
                TxtRtn.Text = Convert.ToString(DgvConfiguracion.CurrentRow.Cells[0].Value);
                TxtNombre.Text = Convert.ToString(DgvConfiguracion.CurrentRow.Cells[1].Value);
            }
            else
            {
                BtnGuardar.Enabled = true;
                BtnCancelar.Enabled = true;
                BtnGestionar.Visible = false;
            }
        }

        public void LimpiarControles()
        {
            foreach (TextBox txt in this.Controls.OfType<TextBox>())
            {
                txt.Clear();
            }
        }
        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            confi.InsertConfiguacion(TxtRtn.Text, TxtNombre.Text, TxtDireccion.Text, TxtCiudad.Text, TxtTelefono.Text, TxtCorreo.Text, TxtSitioWeb.Text, TxtLogo.Text);
            confi.MostrarConfiguracion(DgvConfiguracion);
            LimpiarControles();
            BtnGuardar.Enabled = false;
            BtnGestionar.Visible = true;
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            confi.UpdateConfiguacion(TxtRtn.Text, TxtNombre.Text, TxtDireccion.Text, TxtCiudad.Text, TxtTelefono.Text, TxtCorreo.Text, TxtSitioWeb.Text, TxtLogo.Text);
            confi.MostrarConfiguracion(DgvConfiguracion);
            LimpiarControles();
            BtnGestionar.Visible = true;
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            confi.EliminarConfiguracion(TxtRtn.Text);
            DgvConfiguracion.Rows.Clear();
            LimpiarControles();
            BtnGuardar.Enabled = true;
            BtnGestionar.Visible = false;
            BtnEditar.Enabled = false;
            BtnEliminar.Enabled = false;
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            string msg = "Esta seguro que quiere cancelar";
            if (h.MsgQuestion(msg)=="S")
            {
                LimpiarControles();
            }
        }

        private void DgvConfiguracion_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridView dgv1 = DgvConfiguracion;
                TxtRtn.Text = Convert.ToString(dgv1.CurrentRow.Cells[0].Value);
                TxtNombre.Text = Convert.ToString(dgv1.CurrentRow.Cells[1].Value);
                TxtDireccion.Text = Convert.ToString(dgv1.CurrentRow.Cells[2].Value);
                TxtCiudad.Text = Convert.ToString(dgv1.CurrentRow.Cells[3].Value);
                TxtTelefono.Text = Convert.ToString(dgv1.CurrentRow.Cells[4].Value);
                TxtCorreo.Text = Convert.ToString(dgv1.CurrentRow.Cells[5].Value);
                TxtSitioWeb.Text = Convert.ToString(dgv1.CurrentRow.Cells[6].Value);
                TxtLogo.Text = Convert.ToString(dgv1.CurrentRow.Cells[7].Value);
            }
            BtnEditar.Enabled = true;
            BtnEliminar.Enabled = true;
            BtnGuardar.Enabled = false;
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnGestionar_Click(object sender, EventArgs e)
        {
            Views.Configuracion.ViewCais cais = new ViewCais();
            cais.rtn = TxtRtn.Text.Trim();
            cais.nombre = TxtNombre.Text.Trim();
            cais.ShowDialog();
        }
    }
}
