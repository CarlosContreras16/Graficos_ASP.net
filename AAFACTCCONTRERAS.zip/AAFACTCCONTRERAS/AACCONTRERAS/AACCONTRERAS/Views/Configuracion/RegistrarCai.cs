﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Views.Configuracion
{
    public partial class RegistrarCai : Form
    {
        Controlles.CaisController cais = new Controlles.CaisController();
        Vendor.Helpers h = new Vendor.Helpers();
        Vendor.ORM orm = new Vendor.ORM();

        public string rtn, razonsocial;
        string corre = "CAIS";
        string referencia;
        public string command, _idcai;
        public RegistrarCai()
        {
            InitializeComponent();
        }

        private void TxtPrefijo_TextChanged(object sender, EventArgs e)
        {
            TxtFacturaIni.Text = TxtPrefijo.Text.Trim() + TxtFacInicial.Text.Trim();
        }

        private void TxtFacInicial_TextChanged(object sender, EventArgs e)
        {
            TxtFacturaIni.Text = TxtPrefijo.Text.Trim() + TxtFacInicial.Text.Trim();
        }

        private void TxtFacFinal_TextChanged(object sender, EventArgs e)
        {
            TxtFacturaFin.Text = TxtPrefijo.Text.Trim() + TxtFacFinal.Text.Trim();
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            if (command=="NEW")
            {
                SaveCAI();
            }
            else
            {
                UpdateCAI();   
            }
        }

        private void UpdateCAI()
        {
            if (cais.EditarCais(_idcai, TxtCai.Text, DtFechaLimite.Value, TxtPrefijo.Text, TxtFacturaIni.Text, TxtFacturaFin.Text, DtFechaFin.Value, Vendor.Auth.USERNAME)==true)
            {
                double newcorrefacturacion = h.ReturnsNumber(TxtFacInicial.Text.Trim()) - 1;
                orm.Update("CORRELATIVOS", "ULTIMO=" + newcorrefacturacion + "", "IDCORRE='FACTU'");
                Configuracion.ViewCais cai = new ViewCais();
                cai = ((Configuracion.ViewCais)Owner);
                cai.GetCais();
                Close();
            }
        }

        private void SaveCAI()
        {
            referencia = cais.NewIdCate(corre);
            orm.Update("CAIS", "ESTADO='VENCIDO'");
            if (cais.InsertCais(referencia, TxtCai.Text, DtFechaLimite.Value, TxtPrefijo.Text, TxtFacturaIni.Text, TxtFacturaFin.Text, DtFechaFin.Value, Vendor.Auth.USERNAME) == true)
            {
                double newcorrefacturacion = h.ReturnsNumber(TxtFacInicial.Text.Trim()) - 1;
                orm.Update("CORRELATIVOS", "ULTIMO=" + newcorrefacturacion + "", "IDCORRE='FACTU'");
                orm.SetLast(corre);

                Configuracion.ViewCais cai = new ViewCais();
                cai = ((Configuracion.ViewCais)Owner);
                cai.GetCais();
                Close();
            }
        }

        private void RegistrarCai_Load(object sender, EventArgs e)
        {
            TxtRtn.Text = rtn;
            TxtNombre.Text = razonsocial;
        }

        public void GetInfoCai(string idcai)
        {
            _idcai = idcai;
            string condicion = "REFCAI='" + idcai + "'";
            DataTable data = orm.Find("CAIS", "*", condicion);

            if (data.Rows.Count>0)
            {
                DataRow info = data.Rows[0];
                TxtCai.Text = info["CAI"].ToString();
                DtFechaLimite.Text = info["FECHALIM"].ToString();
                TxtPrefijo.Text = info["PREFIJO"].ToString();
                string facturainicial = info["FACTURAINI"].ToString();
                string x = facturainicial.Substring(11);
                TxtFacInicial.Text = x;
                string facgturafinal = info["FACTURAFIN"].ToString();
                string y = facgturafinal.Substring(11);
                TxtFacFinal.Text = y;
                DtFechaFin.Text = info["FECHAREC"].ToString();
                CbEstado.Text = info["ESTADO"].ToString();
                CbEstado.Visible = true;
                LblEstado.Visible = true;
            }

        }
    }
}
