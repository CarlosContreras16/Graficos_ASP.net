﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AACCONTRERAS.Views
{
    public partial class ViewProductos : Form
    {
        Vendor.ORM orm = new Vendor.ORM();
        Vendor.Helpers h = new Vendor.Helpers();
        Controlles.ProductosController pc = new Controlles.ProductosController();

        // Id del correlativo porductos 
        string IdCorre = "PRODS";
        public string CodBarra = "";
        public string Producto = "";
        public ViewProductos()
        {
            InitializeComponent();
        }

        private void Productos_Load(object sender, EventArgs e)
        {
            this.Text = Env.APPNAME + " | REGISTRO DE PRODUCTOS | " + Vendor.Auth.USERNAME + " | " + Vendor.Auth.ROLE;
            Boot();
            pc.ShowProducto(DgvProductos);
        }

        private void Boot()
        {
            BtnNuevo.Enabled = Vendor.Auth.GUARDAR == "S" ? true : false;
            BtnGuardar.Enabled = false;
            BtnEditar.Enabled = false;
            BtnEliminar.Enabled = false;
            BtnCancelar.Enabled = false;
            BtnSalir.Enabled = true;        

            TxtCodigo.Enabled = false;
            TxtDescripcion.Enabled = false;
            ChkGen.Enabled = true;
            ChkGen.Checked = false;
            CbCateogria.Enabled = false;
            GetCategorias();
            CbMarca.Enabled = false;
            GetMarcas();
            CbFiscal.Enabled = false;
            CbIsv.Enabled = false;
            CbTipo.Enabled = false;
            CbInventario.Enabled = false;
            CbEntrada.Enabled = false;
            GetPresIn();
            CbSalida.Enabled = false;
            GetPresOut();
            TxtIncremento.Enabled = false;
            TxtPrecioD.Enabled = false;
            TxtPrecioM.Enabled = false;
            TxtStockMin.Enabled = false;

            BtnKardex.Enabled = Vendor.Auth.ROLE == "CAJERO" || Vendor.Auth.ROLE == "VENDEDOR" ? false : true; ;
            BtnLotes.Enabled = Vendor.Auth.ROLE == "CAJERO" || Vendor.Auth.ROLE == "VENDEDOR" ? false : true;                                     
            BtnConfEsp.Enabled = Vendor.Auth.ROLE == "CAJERO" || Vendor.Auth.ROLE == "VENDEDOR" ? false : true;
            BtnPapelera.Enabled = Vendor.Auth.ROLE == "CAJERO" || Vendor.Auth.ROLE == "VENDEDOR" ? false : true;
        }

        private void Clean()
        {
            TxtCodigo.Clear(); 
            TxtDescripcion.Clear();
            TxtIncremento.Clear();
            TxtPrecioD.Clear();
            TxtPrecioM.Clear();
            TxtStockMin.Clear();

        }

        private void StarForm()
        {
            TxtCodigo.Enabled = false;
            TxtDescripcion.Enabled = false;
            TxtIncremento.Enabled = false;
            TxtPrecioD.Enabled = false;
            TxtPrecioM.Enabled = false;
            TxtStockMin.Enabled = false;


            //botones del toolstrip
            BtnNuevo.Enabled = true;
            BtnGuardar.Enabled = false;
            BtnEditar.Enabled = false;
            BtnCancelar.Enabled = false;
            BtnSalir.Enabled = true;
            BtnEliminar.Enabled = false;
        }

        private void BtnNuevo_Click(object sender, EventArgs e)
        {
            
            BtnNuevo.Enabled = false;
            BtnGuardar.Enabled = Vendor.Auth.GUARDAR == "S" ? true : false;
            BtnEditar.Enabled = false;
            BtnCancelar.Enabled = true;
            BtnSalir.Enabled = false;
            BtnEliminar.Enabled = false;
            ActivarControles();

            if (ChkGen.Checked==true)
            {
                TxtCodigo.Enabled = false;
                NewCodBarra();
                TxtDescripcion.Focus();
            }
            else
            {
                TxtCodigo.Text = "";
                TxtCodigo.Focus();
            }
         
        }
        public void NewCodBarra()
        {
            TxtCodigo.Text = "PRD" + orm.GetNext(IdCorre);
        }
        public void UpdateCodBarra()
        {
            pc.UpdateCodBarra(IdCorre, TxtDescripcion.Text, CbCateogria.Text, CbMarca.Text, CbFiscal.Text, CbTipo.Text, CbInventario.Text, CbEntrada.Text, CbSalida.Text, TxtIncremento.Text, TxtPrecioD.Text, TxtPrecioM.Text, TxtStockMin.Text);
        }
        public void ActivarControles()
        {
            foreach (TextBox txt in this.Controls.OfType<TextBox>())
            {
                txt.Enabled = true;
            }

            foreach (ComboBox cmb in this.Controls.OfType<ComboBox>())
            {
                cmb.Enabled = true;
            }
        }

        public void LimpiarControles()
        {
            foreach (TextBox txt in this.Controls.OfType<TextBox>())
            {
                txt.Clear();
            }

            foreach (ComboBox cmb in this.Controls.OfType<ComboBox>())
            {
                cmb.SelectedIndex = -1;
            }
        }

        private void BtnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            string msg = "¿CONFIRMA QUE DESEA CANCELAR LA OPERACION DEL CURSO";

            if (h.MsgQuestion(msg)=="S")
            {
                Boot();
                LimpiarControles();
            }          
        }

        private void GetPresIn()
        {
            CbEntrada.DataSource = orm.Find("PRESENTACIONPRODUCTOS", "IDPRES, PRESENTACION", "","PRESENTACION");
            CbEntrada.ValueMember = "IDPRES";
            CbEntrada.DisplayMember = "PRESENTACION";
            CbEntrada.SelectedIndex = -1;
        }
        private void GetPresOut()
        {
            CbSalida.DataSource = orm.Find("PRESENTACIONPRODUCTOS", "IDPRES, PRESENTACION", "", "PRESENTACION");
            CbSalida.ValueMember = "IDPRES";
            CbSalida.DisplayMember = "PRESENTACION";
            CbSalida.SelectedIndex = -1;
        }

        private void GetCategorias()
        {
            DataTable categorias = orm.Find("CATEGORIASPRODUCTOS", "IDCATE, CATEGORIA", "DEL='N'", "CATEGORIA");
            CbCateogria.DataSource = categorias;
            CbCateogria.ValueMember = "IDCATE";
            CbCateogria.DisplayMember = "CATEGORIA";
            CbCateogria.SelectedIndex = -1; 
        }

        private void GetMarcas()
        {
            DataTable marcas = orm.Find("MARCASPRODUCTOS", "IDMARCA, MARCA", "DEL='N'", "MARCA");
            CbMarca.DataSource = marcas;
            CbMarca.ValueMember = "IDMARCA";
            CbMarca.DisplayMember = "MARCA";
            CbMarca.SelectedIndex = -1;
        }

        private void GetInfoProducto(string codprd)
        {
            BtnNuevo.Enabled = false;
            BtnGuardar.Enabled = false;
            BtnEditar.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
            BtnEliminar.Enabled = Vendor.Auth.ELIMINAR == "S" ? true : false;
            BtnCancelar.Enabled = true;
            BtnSalir.Enabled = true;
            string condicion = "CODBARRAS='" + codprd + "'";
            DataTable data = orm.Find("PRODUCTOS", "*", condicion);
            if (data.Rows.Count > 0)
            {
                DataRow info = data.Rows[0];
                TxtCodigo.Text = info["CODBARRAS"].ToString();
                TxtDescripcion.Text = info["DESCRIPCION"].ToString();
                CbCateogria.SelectedValue = info["IDCATE"].ToString();
                CbMarca.SelectedValue = info["IDMARCA"].ToString();
                CbFiscal.Text = info["FISCAL"].ToString();
                CbIsv.Text = info["ISV"].ToString();
                CbTipo.Text = info["TIPOPROD"].ToString();
                CbInventario.Text = info["MINV"].ToString();
                CbEntrada.SelectedValue = info["IDPRES_IN"].ToString();
                CbSalida.SelectedValue = info["IDPRES_OUT"].ToString();
                TxtIncremento.Text = info["INCREMENT"].ToString();
                TxtPrecioD.Text = info["PRECIODET"].ToString();
                TxtPrecioM.Text = info["PRECIOMAY"].ToString();
                TxtStockMin.Text = info["STOCKMIN"].ToString();

                TxtCodigo.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                TxtDescripcion.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                CbCateogria.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                CbMarca.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                CbFiscal.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                CbIsv.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                CbTipo.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                CbInventario.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                CbEntrada.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                CbSalida.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                TxtIncremento.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                TxtPrecioD.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                TxtPrecioM.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
                TxtStockMin.Enabled = Vendor.Auth.ACTUALIZAR == "S" ? true : false;
            }
            else
            {
                h.Warning("ERROR AL RECUPERAR LOS DATOS DEL PRODUCTO SELECCIONADO!");
            }              
        }

        private void GetDeleteRows()
        {
            string campos = "CODBARRAS, DESCRIPCION, PRECIODET";
            DataTable data = orm.Find("PRODUCTOS", campos, "DEL='S'");
            
            DgvProductos.Rows.Clear();
            string _cod, _prod;
            double _precio;

            for (int i = 0; i < data.Rows.Count; i++)
            {
                _cod = data.Rows[i][0].ToString();
                _prod = data.Rows[i][1].ToString();
                _precio = h.ReturnsNumber(data.Rows[i][2].ToString());

                DgvProductos.Rows.Add(_cod, _prod, _precio);
            }
            if (DgvProductos.Rows.Count>0)
            {
                for (int i = 0; i < DgvProductos.Rows.Count; i++)
                {
                    DgvProductos.Rows[i].DefaultCellStyle.ForeColor = Color.Red;
                }
            }
        }
        private void RestoreDeleteRows(string codbarra)
        {
            string msg = "DESEA REALMENTE RECUPERAR EL REGISTRO?";
            if (h.MsgQuestion(msg)=="S")
            {
                if (orm.Update("PRODUCTOS","DEL='N'", "CODBARRAS='"+codbarra+"'")>0)
                {
                    h.MsgSuccess("EL REGISTRO SE RECUPERO CON EXITO");
                    GetDeleteRows();
                }
            }
        }
          private void label5_Click(object sender, EventArgs e)
        {

        }

        private void TxtIncremento_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = h.GetOnlyNumbers(e) ? false : true;
        }

        private void TxtPrecioD_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = h.GetMoneyValue(e) ? false : true;
        }

        private void TxtPrecioM_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = h.GetMoneyValue(e) ? false : true;
        }

        private void TxtStockMin_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = h.GetOnlyNumbers(e) ? false : true;
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            pc.InsertProducto(TxtCodigo.Text, TxtDescripcion.Text, CbCateogria.SelectedValue.ToString(), CbMarca.SelectedValue.ToString(), CbFiscal.Text, CbIsv.Text, CbTipo.Text,CbInventario.Text, CbEntrada.SelectedValue.ToString(), CbSalida.SelectedValue.ToString(),TxtIncremento.Text, TxtPrecioD.Text,TxtPrecioM.Text, TxtStockMin.Text);
            pc.ShowProducto(DgvProductos);
            UpdateCodBarra();
            LimpiarControles();
            Boot();
        }

        private void CbFiscal_SelectedValueChanged(object sender, EventArgs e)
        {
            if (CbFiscal.Text == "EXONERADO")
            {
                CbIsv.SelectedIndex = 0;
                CbIsv.Enabled = false;
            }
            else if(CbFiscal.Text == "EXENTO")
            {
                CbIsv.SelectedIndex = 1;
                CbIsv.Enabled = false;
            }
            else if (CbFiscal.Text == "GRAVADO")
            {
                CbIsv.SelectedIndex = 2;
                CbIsv.Enabled = false;
            }
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            pc.UpdateProducto(TxtCodigo.Text, TxtDescripcion.Text, CbCateogria.ValueMember, CbMarca.ValueMember, CbFiscal.Text, CbIsv.Text, CbTipo.Text, CbInventario.Text, CbEntrada.Text, CbSalida.Text, TxtIncremento.Text, TxtPrecioD.Text, TxtPrecioM.Text, TxtStockMin.Text);
            pc.ShowProducto(DgvProductos);
            LimpiarControles();
            Boot();
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            string msg = "¿Eliminar er registro seleccionado";
            if (h.MsgQuestion(msg)=="S")
            {
                if (pc.DeleteProducto(TxtCodigo.Text)==true)
                {
                    h.MsgSuccess("EL REGISTRO SE ELIMINO CORRECTAMENTE");
                    pc.ShowProducto(DgvProductos);
                    LimpiarControles();
                    Boot();
                }
            }       
        }

        private void DgvProductos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (DgvProductos.Rows.Count>0)
            {
                string codprod = DgvProductos.CurrentRow.Cells[0].Value.ToString();
                GetInfoProducto(codprod);
            }  
        }

        private void BtnLotes_Click(object sender, EventArgs e)
        {

            DataGridView dgv1 = DgvProductos;
            if (dgv1.SelectedRows.Count > 0)
            {
                Program.CodProducto = Convert.ToString(dgv1.CurrentRow.Cells[0].Value.ToString());
                Program.Producto = Convert.ToString(dgv1.CurrentRow.Cells[1].Value.ToString());

                Lotes lotes = new Lotes();
                //lotes = ((Lotes)Owner);
                this.AddOwnedForm(lotes);
                lotes.ShowDialog();
            }
            else
            {
                h.Warning("Selecciones una Fila");
            }
        }

        private void BtnPapelera_Click(object sender, EventArgs e)
        {
            if (BtnPapelera.Text=="Papelera")
            {
                GetDeleteRows();
                BtnRestaurar.Visible = true;
                BtnDestroy.Visible = true;
                BtnPapelera.Text = "Regresar";
            }
            else
            {
                BtnRestaurar.Visible = false;
                BtnDestroy.Visible = false;
                BtnPapelera.Text = "Papelera";
                pc.ShowProducto(DgvProductos);
            }
        }

        private void BtnRestaurar_Click(object sender, EventArgs e)
        {
            string cod = DgvProductos.Rows.Count > 0 ? DgvProductos.CurrentRow.Cells[0].Value.ToString() : "";
            if (cod!="")
            {
                RestoreDeleteRows(cod);
            }
        }
    }
}
