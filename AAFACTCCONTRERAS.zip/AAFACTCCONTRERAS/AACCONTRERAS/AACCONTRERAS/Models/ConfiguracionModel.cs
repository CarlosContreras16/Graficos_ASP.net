﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace AACCONTRERAS.Models
{
    class ConfiguracionModel
    {
        Vendor.ORM orm = new Vendor.ORM();
        Vendor.Helpers h = new Vendor.Helpers();

        public bool InsertConfi(string rtn, string nombreorazon, string direccion, string ciudad, string telefonos, string correo, string website, string logo)
        {
            bool response = false;

            string condition = "RTN, NOMBREORAZON, DIRECCION, CIUDAD, TELEFONOS, CORREO, WEBSITE, LOGO";
            string values = "'" + rtn + "', '" + nombreorazon + "', '" + direccion + "', '" + ciudad + "', '" + telefonos + "', '" + correo + "', '" + website + "', '" + logo + "'";

            try
            {
                if (orm.Save("INFOGRAL", condition, values) > 0)
                {
                    h.MsgSuccess("La configuracion ha sido ingresada correctamente");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }
            return response;
        }
        public bool UpdateConfi(string rtn, string nombreorazon, string direccion, string ciudad, string telefonos, string correo, string website, string logo)
        {
            bool response = false;

            string data = "NOMBREORAZON='" + nombreorazon + "', DIRECCION='" + direccion + "',CIUDAD='" + ciudad + "',TELEFONOS='" + telefonos + "',CORREO='" + correo + "',WEBSITE='" + website + "', LOGO='" + logo + "'";
            string condition = "RTN='" + rtn + "'";

            try
            {
                if (orm.Update("INFOGRAL", data, condition) > 0)
                {
                    h.MsgSuccess("CONFIGURACION ACTUALIZADA CORRECTAMENTE");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }

            return response;
        }

        public bool DeleteConfi(string value)
        {
            bool response = false;
            string condition = "RTN";


            try
            {
                if (orm.Destroy("INFOGRAL", "RTN='" + value + "'") >0)
                {
                    h.MsgSuccess("CONFIGURACION ELIMINADA CORRECTAMENTE");
                    response = true;
                }
            }
            catch (SqlException ex)
            {
                h.Warning("ERROR: " + ex.ToString());
            }

            return response;
        }

        public bool ShowConfi(DataGridView dgv)
        {
            string rtn, nombreorazon, direccion, ciudad, telefonos, correo, website, logo;
            bool response = false;
            DataTable registros;
            registros = new DataTable();
            registros = orm.Find("INFOGRAL", "*");
            if (registros.Rows.Count > 0)
            {
                dgv.Rows.Clear();
                int i;
                for (i = 0; i < registros.Rows.Count; i++)
                {
                    rtn = registros.Rows[i][0].ToString();
                    nombreorazon = registros.Rows[i][1].ToString();
                    direccion = registros.Rows[i][2].ToString();
                    ciudad = registros.Rows[i][3].ToString();
                    telefonos = registros.Rows[i][4].ToString();
                    correo = registros.Rows[i][5].ToString();
                    website = registros.Rows[i][6].ToString();
                    logo = registros.Rows[i][7].ToString();
                    dgv.Rows.Add(rtn, nombreorazon, direccion, ciudad, telefonos, correo, website, logo);
                }
            }
            return response;
        }
    }
}
