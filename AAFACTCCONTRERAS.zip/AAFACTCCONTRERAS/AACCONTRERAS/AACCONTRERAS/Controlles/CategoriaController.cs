﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace AACCONTRERAS.Controlles
{
    class CategoriaController
    {
        Vendor.Helpers h = new Vendor.Helpers();
        Vendor.ORM orm = new Vendor.ORM();
        Models.CategoriasProdModel cm = new Models.CategoriasProdModel();

        public bool InsertCategoria(string idcate, string cate)
        {
            bool response = true;
            string id = h.Clean(idcate.Trim());
            string cat = h.Clean(cate.Trim());
            string errors = "";

            if (id.Length == 0)
            {
                errors = "INGRESAR CODIGO\n";
                response = false;
            }
            if (cat.Length == 0)
            {
                errors += "INGRESAR CATEGORIA";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = cm.InsertCategoria(id, cat);
            }
            return response;
        }
        public bool EditarCategoria(string idcate, string cate)
        {
            bool response = true;
            string id = h.Clean(idcate.Trim());
            string cat = h.Clean(cate.Trim());
            string errors = "";

            if (id.Length == 0)
            {
                errors = "INGRESAR CODIGO\n";
                response = false;
            }
            if (cat.Length == 0)
            {
                errors += "INGRESAR CATEGORIA";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = cm.UpdateCategoria(id, cat);
            }
            return response;
        }

        public bool EliminarCategoria(string value)
        {
            bool response = true;
            string val = h.Clean(value.Trim());
            string errors = "";
            if (val.Length == 0)
            {
                errors += "INGRESAR CATEGORIA";
                response = false;
            }
            if (response == false)
            {
                h.Warning(errors);
            }
            else
            {
                response = cm.DeleteCategoria(val);
            }
            return response;
        }
        public bool MostrarCategorias(DataGridView dgv)
        {
            bool response = true;

            if (response == false)
            {
                h.Warning("Error");
            }
            else
            {
                response = cm.ShowCategorias(dgv);
            }
            return response;
        }
        public bool Buscarcat(DataGridView dgv, string buscar)
        {
            bool response = true;
            if (response == false)
            {
                h.Warning("Error");
            }
            else
            {
                response = cm.BuscarCategoria(dgv, buscar);
            }
            return response;
        }
        public string NewIdCate(string idcorre)
        {
            string id = "";
            id = cm.NewIdCate(idcorre);

            return id;
        }

        public void UpdateIdCate(string id, string marca)
        {
            if (marca.Length == 0)
            {
                return;
            }
            else
            {
                cm.UpdateIdCate(id);
            }
        }
    }
}

