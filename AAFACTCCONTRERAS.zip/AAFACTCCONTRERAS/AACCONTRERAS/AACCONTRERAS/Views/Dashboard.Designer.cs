﻿
namespace AACCONTRERAS.Views
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.StbPrincipal = new System.Windows.Forms.StatusStrip();
            this.LblUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.LblPerfil = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.LblFecha = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.TspPrincipal = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnClientes = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnProductos = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnConfiguracion = new System.Windows.Forms.ToolStripButton();
            this.MnsPrincipal = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpcClientes = new System.Windows.Forms.ToolStripMenuItem();
            this.productosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marcasProductosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoriasProductosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aperturaCajaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OptProductos = new System.Windows.Forms.ToolStripMenuItem();
            this.OptReportes = new System.Windows.Forms.ToolStripMenuItem();
            this.OptConfiguracion = new System.Windows.Forms.ToolStripMenuItem();
            this.OptInfoGral = new System.Windows.Forms.ToolStripMenuItem();
            this.sistemaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cambiarClaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnVentas = new System.Windows.Forms.ToolStripButton();
            this.facturacionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.StbPrincipal.SuspendLayout();
            this.TspPrincipal.SuspendLayout();
            this.MnsPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // StbPrincipal
            // 
            this.StbPrincipal.AutoSize = false;
            this.StbPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LblUser,
            this.toolStripSeparator2,
            this.LblPerfil,
            this.toolStripSeparator3,
            this.LblFecha,
            this.toolStripSeparator4});
            this.StbPrincipal.Location = new System.Drawing.Point(0, 308);
            this.StbPrincipal.Name = "StbPrincipal";
            this.StbPrincipal.Size = new System.Drawing.Size(665, 29);
            this.StbPrincipal.TabIndex = 0;
            this.StbPrincipal.Text = "statusStrip1";
            // 
            // LblUser
            // 
            this.LblUser.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblUser.Image = ((System.Drawing.Image)(resources.GetObject("LblUser.Image")));
            this.LblUser.Name = "LblUser";
            this.LblUser.Size = new System.Drawing.Size(35, 24);
            this.LblUser.Text = "---";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 29);
            // 
            // LblPerfil
            // 
            this.LblPerfil.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPerfil.Image = ((System.Drawing.Image)(resources.GetObject("LblPerfil.Image")));
            this.LblPerfil.Name = "LblPerfil";
            this.LblPerfil.Size = new System.Drawing.Size(35, 24);
            this.LblPerfil.Text = "---";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 29);
            // 
            // LblFecha
            // 
            this.LblFecha.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFecha.Image = ((System.Drawing.Image)(resources.GetObject("LblFecha.Image")));
            this.LblFecha.Name = "LblFecha";
            this.LblFecha.Size = new System.Drawing.Size(35, 24);
            this.LblFecha.Text = "---";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 29);
            // 
            // TspPrincipal
            // 
            this.TspPrincipal.AutoSize = false;
            this.TspPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.BtnClientes,
            this.toolStripSeparator5,
            this.BtnProductos,
            this.toolStripSeparator6,
            this.BtnConfiguracion,
            this.toolStripSeparator7,
            this.BtnVentas});
            this.TspPrincipal.Location = new System.Drawing.Point(0, 24);
            this.TspPrincipal.Name = "TspPrincipal";
            this.TspPrincipal.Size = new System.Drawing.Size(665, 32);
            this.TspPrincipal.TabIndex = 1;
            this.TspPrincipal.Text = "toolStrip1";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 32);
            // 
            // BtnClientes
            // 
            this.BtnClientes.Image = ((System.Drawing.Image)(resources.GetObject("BtnClientes.Image")));
            this.BtnClientes.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnClientes.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnClientes.Name = "BtnClientes";
            this.BtnClientes.Size = new System.Drawing.Size(77, 29);
            this.BtnClientes.Text = "Clientes";
            this.BtnClientes.Click += new System.EventHandler(this.BtnClientes_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 32);
            // 
            // BtnProductos
            // 
            this.BtnProductos.Image = ((System.Drawing.Image)(resources.GetObject("BtnProductos.Image")));
            this.BtnProductos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnProductos.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnProductos.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnProductos.Name = "BtnProductos";
            this.BtnProductos.Size = new System.Drawing.Size(89, 29);
            this.BtnProductos.Text = "Productos";
            this.BtnProductos.Click += new System.EventHandler(this.BtnProductos_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 32);
            // 
            // BtnConfiguracion
            // 
            this.BtnConfiguracion.Image = ((System.Drawing.Image)(resources.GetObject("BtnConfiguracion.Image")));
            this.BtnConfiguracion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnConfiguracion.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnConfiguracion.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnConfiguracion.Name = "BtnConfiguracion";
            this.BtnConfiguracion.Size = new System.Drawing.Size(111, 29);
            this.BtnConfiguracion.Text = "Configuracion";
            this.BtnConfiguracion.Click += new System.EventHandler(this.BtnConfiguracion_Click);
            // 
            // MnsPrincipal
            // 
            this.MnsPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem,
            this.ventasToolStripMenuItem,
            this.OptProductos,
            this.OptReportes,
            this.OptConfiguracion,
            this.sistemaToolStripMenuItem});
            this.MnsPrincipal.Location = new System.Drawing.Point(0, 0);
            this.MnsPrincipal.Name = "MnsPrincipal";
            this.MnsPrincipal.Size = new System.Drawing.Size(665, 24);
            this.MnsPrincipal.TabIndex = 2;
            this.MnsPrincipal.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OpcClientes,
            this.productosToolStripMenuItem});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.archivoToolStripMenuItem.Text = "Archivo";
            // 
            // OpcClientes
            // 
            this.OpcClientes.Image = ((System.Drawing.Image)(resources.GetObject("OpcClientes.Image")));
            this.OpcClientes.Name = "OpcClientes";
            this.OpcClientes.Size = new System.Drawing.Size(180, 22);
            this.OpcClientes.Text = "Clientes";
            this.OpcClientes.Click += new System.EventHandler(this.OpcClientes_Click);
            // 
            // productosToolStripMenuItem
            // 
            this.productosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.marcasProductosToolStripMenuItem,
            this.categoriasProductosToolStripMenuItem});
            this.productosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("productosToolStripMenuItem.Image")));
            this.productosToolStripMenuItem.Name = "productosToolStripMenuItem";
            this.productosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.productosToolStripMenuItem.Text = "Productos";
            this.productosToolStripMenuItem.Click += new System.EventHandler(this.productosToolStripMenuItem_Click);
            // 
            // marcasProductosToolStripMenuItem
            // 
            this.marcasProductosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("marcasProductosToolStripMenuItem.Image")));
            this.marcasProductosToolStripMenuItem.Name = "marcasProductosToolStripMenuItem";
            this.marcasProductosToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.marcasProductosToolStripMenuItem.Text = "Marcas Productos";
            this.marcasProductosToolStripMenuItem.Click += new System.EventHandler(this.marcasProductosToolStripMenuItem_Click);
            // 
            // categoriasProductosToolStripMenuItem
            // 
            this.categoriasProductosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("categoriasProductosToolStripMenuItem.Image")));
            this.categoriasProductosToolStripMenuItem.Name = "categoriasProductosToolStripMenuItem";
            this.categoriasProductosToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.categoriasProductosToolStripMenuItem.Text = "Categorias Productos";
            this.categoriasProductosToolStripMenuItem.Click += new System.EventHandler(this.categoriasProductosToolStripMenuItem_Click);
            // 
            // ventasToolStripMenuItem
            // 
            this.ventasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aperturaCajaToolStripMenuItem,
            this.facturacionToolStripMenuItem});
            this.ventasToolStripMenuItem.Name = "ventasToolStripMenuItem";
            this.ventasToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.ventasToolStripMenuItem.Text = "Ventas";
            // 
            // aperturaCajaToolStripMenuItem
            // 
            this.aperturaCajaToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("aperturaCajaToolStripMenuItem.Image")));
            this.aperturaCajaToolStripMenuItem.Name = "aperturaCajaToolStripMenuItem";
            this.aperturaCajaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.aperturaCajaToolStripMenuItem.Text = "Apertura Caja";
            this.aperturaCajaToolStripMenuItem.Click += new System.EventHandler(this.aperturaCajaToolStripMenuItem_Click);
            // 
            // OptProductos
            // 
            this.OptProductos.Name = "OptProductos";
            this.OptProductos.Size = new System.Drawing.Size(73, 20);
            this.OptProductos.Text = "Productos";
            // 
            // OptReportes
            // 
            this.OptReportes.Name = "OptReportes";
            this.OptReportes.Size = new System.Drawing.Size(65, 20);
            this.OptReportes.Text = "Reportes";
            // 
            // OptConfiguracion
            // 
            this.OptConfiguracion.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OptInfoGral});
            this.OptConfiguracion.Name = "OptConfiguracion";
            this.OptConfiguracion.Size = new System.Drawing.Size(95, 20);
            this.OptConfiguracion.Text = "Configuracion";
            // 
            // OptInfoGral
            // 
            this.OptInfoGral.Name = "OptInfoGral";
            this.OptInfoGral.Size = new System.Drawing.Size(182, 22);
            this.OptInfoGral.Text = "Informacion General";
            this.OptInfoGral.Click += new System.EventHandler(this.OptInfoGral_Click);
            // 
            // sistemaToolStripMenuItem
            // 
            this.sistemaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cambiarClaveToolStripMenuItem});
            this.sistemaToolStripMenuItem.Name = "sistemaToolStripMenuItem";
            this.sistemaToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.sistemaToolStripMenuItem.Text = "Sistema";
            // 
            // cambiarClaveToolStripMenuItem
            // 
            this.cambiarClaveToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cambiarClaveToolStripMenuItem.Image")));
            this.cambiarClaveToolStripMenuItem.Name = "cambiarClaveToolStripMenuItem";
            this.cambiarClaveToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.cambiarClaveToolStripMenuItem.Text = "Cambiar Clave";
            this.cambiarClaveToolStripMenuItem.Click += new System.EventHandler(this.cambiarClaveToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 32);
            // 
            // BtnVentas
            // 
            this.BtnVentas.Image = ((System.Drawing.Image)(resources.GetObject("BtnVentas.Image")));
            this.BtnVentas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnVentas.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnVentas.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnVentas.Name = "BtnVentas";
            this.BtnVentas.Size = new System.Drawing.Size(97, 29);
            this.BtnVentas.Text = "Facturacion";
            this.BtnVentas.Click += new System.EventHandler(this.BtnVentas_Click);
            // 
            // facturacionToolStripMenuItem
            // 
            this.facturacionToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("facturacionToolStripMenuItem.Image")));
            this.facturacionToolStripMenuItem.Name = "facturacionToolStripMenuItem";
            this.facturacionToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.facturacionToolStripMenuItem.Text = "Facturacion";
            this.facturacionToolStripMenuItem.Click += new System.EventHandler(this.facturacionToolStripMenuItem_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(665, 337);
            this.Controls.Add(this.TspPrincipal);
            this.Controls.Add(this.StbPrincipal);
            this.Controls.Add(this.MnsPrincipal);
            this.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.MnsPrincipal;
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "";
            this.Text = "---";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Dashboard_FormClosing);
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.StbPrincipal.ResumeLayout(false);
            this.StbPrincipal.PerformLayout();
            this.TspPrincipal.ResumeLayout(false);
            this.TspPrincipal.PerformLayout();
            this.MnsPrincipal.ResumeLayout(false);
            this.MnsPrincipal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip StbPrincipal;
        private System.Windows.Forms.ToolStripStatusLabel LblUser;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripStatusLabel LblPerfil;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripStatusLabel LblFecha;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStrip TspPrincipal;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton BtnClientes;
        private System.Windows.Forms.MenuStrip MnsPrincipal;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OpcClientes;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem productosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marcasProductosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem categoriasProductosToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton BtnProductos;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton BtnConfiguracion;
        private System.Windows.Forms.ToolStripMenuItem OptProductos;
        private System.Windows.Forms.ToolStripMenuItem OptReportes;
        private System.Windows.Forms.ToolStripMenuItem OptConfiguracion;
        private System.Windows.Forms.ToolStripMenuItem OptInfoGral;
        private System.Windows.Forms.ToolStripMenuItem sistemaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cambiarClaveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aperturaCajaToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton BtnVentas;
        private System.Windows.Forms.ToolStripMenuItem facturacionToolStripMenuItem;
    }
}